# Docker Quick Start - 60 Seconds to Running NetBox

Get NetBox + Network Operations plugin running in 1 minute.

## Prerequisites

- Docker installed
- Docker Compose installed
- 2GB RAM available

## Installation

```bash
# 1. Navigate to docker directory
cd netbox-network-ops-v1.0/docker

# 2. Configure device credentials
nano env/netbox.env
# Edit these lines:
# NETOPS_USERNAME_1=your_device_username
# NETOPS_PASSWORD_1=your_device_password

# 3. Start services
docker-compose up -d

# 4. Wait for initialization (60 seconds)
docker-compose logs -f netbox
# Wait for: "✅ Initialization complete"
# Press Ctrl+C when done

# 5. Open NetBox
# Browser: http://localhost:8000
# Login: admin / admin
```

## First Facts Collection

1. **Add a device in NetBox:**
   - Devices → Add Device
   - Set Name, Platform (cisco_ios/junos/etc)
   - Set Primary IPv4

2. **Collect facts:**
   - Plugins → Network Operations
   - Select device
   - Click "Collect Facts"
   - Watch progress
   - View comparison

## What Was Installed

```
docker/
├── NetBox (port 8000)      - Web interface
├── Worker                   - Background jobs
├── PostgreSQL (port 5432)   - Database
└── Redis (port 6379)        - Cache/Queue

Plugin: netbox_network_ops   - Mounted and installed
```

## Common Commands

```bash
cd docker

# View logs
make logs

# Restart services
make restart

# Open shell
make shell

# Stop everything
make stop
```

## Volume Mounts

The plugin is mounted from the parent directory:

```yaml
# Read-only mount - no confusion!
../netbox_network_ops:/plugins/netbox-network-ops:ro
```

**Key points:**
- Plugin directory is `../netbox_network_ops/` (one level up)
- Mounted as read-only (`:ro`) for safety
- Changes require restart: `make restart`
- No need to rebuild containers

## Configuration Files

```
env/netbox.env       - Credentials, settings
env/postgres.env     - Database config
env/redis.env        - Redis config
configuration/       - NetBox configuration
```

## Production Deployment

Before production:

1. **Change passwords** in `env/netbox.env`:
   ```bash
   SECRET_KEY=<generate-new>
   SUPERUSER_PASSWORD=<change-me>
   DB_PASSWORD=<change-me>
   REDIS_PASSWORD=<change-me>
   NETOPS_PASSWORD_1=<your-device-password>
   ```

2. **Set production mode**:
   ```bash
   DEBUG=false
   DEVELOPER=false
   ALLOWED_HOSTS=yourdomain.com
   ```

3. **Read full guide**:
   ```bash
   cat docker/README-DOCKER.md
   ```

## Troubleshooting

### Plugin not appearing?
```bash
# Check installation
docker-compose exec netbox pip list | grep netbox-network-ops

# Check logs
docker-compose logs netbox | grep -i error

# Restart
docker-compose restart netbox worker
```

### Can't connect to device?
```bash
# Test from container
docker-compose exec netbox ssh admin@device-ip

# Check credentials
docker-compose exec netbox env | grep NETOPS
```

### Jobs not running?
```bash
# Check worker
docker-compose logs worker

# Restart worker
docker-compose restart worker
```

## File Structure

```
netbox-network-ops-v1.0/
├── docker/                    ← You are here
│   ├── docker-compose.yml     ← Service definitions
│   ├── Dockerfile             ← NetBox image
│   ├── entrypoint.sh          ← Startup script
│   ├── env/                   ← Configuration
│   ├── configuration/         ← NetBox config
│   ├── Makefile               ← Convenience commands
│   └── README-DOCKER.md       ← Full documentation
│
├── netbox_network_ops/        ← Plugin source (mounted)
│   ├── __init__.py
│   ├── models.py
│   ├── views.py
│   └── ...
│
├── README.md                  ← Feature overview
├── DOCUMENTATION.md           ← Complete guide
└── DEPLOYMENT.md              ← Production deployment
```

## Next Steps

1. **Add more devices** in NetBox with primary_ip4
2. **Collect facts** from multiple devices
3. **Review logs** to understand behavior
4. **Read full docs** for advanced features
5. **Configure security** before production

## Support

- **Docker Guide:** `docker/README-DOCKER.md` (comprehensive)
- **Plugin Docs:** `../DOCUMENTATION.md` (troubleshooting, FAQ)
- **Quick Start:** `../QUICKSTART.md` (plugin features)

---

**🚀 You're Running NetBox with Network Operations Plugin!**

Access: http://localhost:8000 (admin / admin)

The plugin automatically collects device facts via SSH and displays
them alongside NetBox data for verification.
