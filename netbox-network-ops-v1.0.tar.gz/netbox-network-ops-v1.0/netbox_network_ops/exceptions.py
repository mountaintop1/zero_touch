"""
Custom exception classes for network operations.

These exceptions provide a clean abstraction layer over NAPALM's exception types,
preventing NAPALM implementation details from leaking to callers.
"""


class ConnectionError(Exception):
    """Base class for all connection errors."""

    def __init__(self, message, original_exception=None):
        """
        Initialize connection error.

        Args:
            message: Error message to display
            original_exception: Original exception that triggered this error (optional)
        """
        self.message = message
        self.original_exception = original_exception
        super().__init__(message)

    def __str__(self):
        return self.message


class AuthenticationError(ConnectionError):
    """Authentication or credential failure errors."""
    pass


class TimeoutError(ConnectionError):
    """Connection timeout errors."""
    pass


class PlatformError(ConnectionError):
    """Platform detection or mapping errors."""
    pass


class UnsupportedPlatformError(ConnectionError):
    """Platform is not supported for facts collection."""
    pass
