"""
Device connection management using NAPALM.

Provides DeviceConnector class for establishing SSH connections to network
devices with credential fallback, timeout handling, and credential memory.
"""

import logging
from napalm import get_network_driver
from napalm.base.exceptions import (
    ConnectAuthError,
    ConnectTimeoutError,
    ConnectionException
)
from .credentials import get_credential_sets
from .platforms import get_driver_for_platform
from .exceptions import ConnectionError, AuthenticationError, TimeoutError, PlatformError

logger = logging.getLogger(__name__)

# Connection timeout in seconds
CONNECTION_TIMEOUT = 30

# Maximum number of retry attempts on timeout before giving up
MAX_TIMEOUT_RETRIES = 1


def get_prioritized_credentials(credential_sets, last_successful_index):
    """
    Reorder credentials to try last successful credential first.

    Args:
        credential_sets: List of (username, password) tuples
        last_successful_index: Index (1-based) of credential that last succeeded

    Returns:
        List of (username, password) tuples with successful credential first
    """
    if last_successful_index and 1 <= last_successful_index <= len(credential_sets):
        # Make a copy to avoid modifying original
        reordered = credential_sets.copy()
        # Remove the successful credential from its position (convert to 0-based index)
        successful_cred = reordered.pop(last_successful_index - 1)
        # Insert at the front
        reordered.insert(0, successful_cred)
        return reordered
    else:
        return credential_sets


class DeviceConnector:
    """
    Manages NAPALM SSH connections to network devices.

    Provides credential fallback (tries multiple credential sets on authentication
    failure), timeout handling (aborts immediately on network errors), and credential
    memory (prioritizes previously successful credentials).

    Usage:
        with DeviceConnector(device) as connector:
            driver = connector.get_driver()
            facts = driver.get_facts()
        # Connection automatically closed even if exception occurs
    """

    def __init__(self, device):
        """
        Initialize connector for a NetBox device.

        Args:
            device: NetBox Device object with primary_ip4 and platform

        Raises:
            PlatformError: If device has no platform or unsupported platform
        """
        self.device = device

        # Extract hostname (IP address without CIDR notation)
        if device.primary_ip4:
            self.hostname = str(device.primary_ip4.address.ip)
        else:
            self.hostname = None

        # Extract platform slug
        self.platform_slug = device.platform.slug if device.platform else None

        # Get NAPALM driver name for this platform
        self.driver_name = get_driver_for_platform(self.platform_slug)

        # Connection state
        self.connected = False
        self._driver_instance = None

    def _get_optional_args(self):
        """
        Return NAPALM optional_args based on driver type.

        Returns:
            dict: Driver-specific optional arguments for NAPALM initialization

        Note:
            - ssh_strict=False: Don't validate SSH host keys (common in network automation)
            - keepalive=30: SSH keepalive interval to prevent connection drops
            - disabled_algorithms: Enable legacy SSH algorithms by disabling modern ones,
              forcing Paramiko to negotiate weaker algorithms supported by aging devices
              (Cisco IOS 12.x, old NXOS). Counter-intuitive: we disable modern algorithms
              to enable legacy ones as fallback.
            - auto_probe=0 (JunOS only): Disable auto-probing which can interfere with
              timeout behavior (NAPALM GitHub issue #1115)
        """
        base_args = {
            'ssh_strict': False,  # Don't validate host keys (common in network automation)
            'keepalive': 30,      # SSH keepalive interval
            # Enable legacy SSH algorithms by disabling modern ones - forces Paramiko to
            # negotiate weaker algorithms supported by aging devices (Cisco IOS 12.x, old NXOS)
            'disabled_algorithms': {
                # Disable modern KEX to force fallback to legacy diffie-hellman-group1-sha1, diffie-hellman-group14-sha1
                'kex': [
                    'curve25519-sha256',
                    'curve25519-sha256@libssh.org',
                    'diffie-hellman-group-exchange-sha256',
                    'diffie-hellman-group16-sha512',
                    'diffie-hellman-group18-sha512',
                ],
                # Disable modern host key algorithms to allow ssh-rsa, ssh-dss
                'keys': [
                    'rsa-sha2-512',
                    'rsa-sha2-256',
                ]
            }
        }

        # JunOS-specific: disable auto_probe which can interfere with timeout
        # See NAPALM GitHub issue #1115
        if self.driver_name == 'junos':
            base_args['auto_probe'] = 0

        return base_args

    def connect(self, device_facts=None):
        """
        Connect to device using NAPALM with credential fallback and timeout retry.

        Tries each credential set in order. On authentication failure, tries next
        credential. On timeout, retries once with same credential before aborting.
        On network failure, aborts immediately without trying remaining credentials.

        If device_facts.successful_credential_index is provided, tries that credential
        first before falling back to others.

        Args:
            device_facts: Optional DeviceFacts instance with successful_credential_index

        Returns:
            int: Index (1-based) of credential set that succeeded

        Raises:
            AuthenticationError: All credentials failed authentication
            TimeoutError: Connection timeout after retries (no credential fallback)
            ConnectionError: Network error (no credential fallback)
            PlatformError: Platform not supported or driver not found
        """
        if not self.hostname:
            raise ConnectionError(
                f"Device {self.device.name} has no primary IPv4 address",
                None
            )

        # Get all credential sets
        credential_sets = get_credential_sets()

        # Prioritize last successful credential if available
        if device_facts and device_facts.successful_credential_index:
            credential_sets = get_prioritized_credentials(
                credential_sets,
                device_facts.successful_credential_index
            )

        last_exception = None

        # Try each credential set
        for index, (username, password) in enumerate(credential_sets, start=1):
            retries_remaining = MAX_TIMEOUT_RETRIES

            while True:  # Retry loop for timeout
                try:
                    # Get NAPALM driver class
                    driver_class = get_network_driver(self.driver_name)

                    # Create driver instance with connection parameters
                    self._driver_instance = driver_class(
                        hostname=self.hostname,
                        username=username,
                        password=password,
                        timeout=CONNECTION_TIMEOUT,
                        optional_args=self._get_optional_args()
                    )

                    # Open the connection
                    self._driver_instance.open()
                    self.connected = True

                    logger.info(
                        f"Connected to {self.device.name} with credential set {index}"
                    )

                    # Log connection algorithm details for diagnostics (best-effort)
                    try:
                        transport = self._driver_instance.device.remote_conn.get_transport()
                        if transport:
                            # Attempt to get KEX info from transport
                            kex_info = getattr(transport, 'local_kex_init', 'unknown')
                            logger.info(
                                f"SSH session established to {self.device.name}: "
                                f"KEX={kex_info}"
                            )
                    except Exception:
                        # Don't fail connection if logging fails
                        pass

                    return index

                except ConnectAuthError as e:
                    # Authentication failed - try next credential (break retry loop)
                    logger.debug(
                        f"Credential set {index} authentication failed for {self.device.name}"
                    )
                    last_exception = AuthenticationError(
                        f"Authentication failed for {self.device.name}",
                        e
                    )
                    break  # Exit retry loop, continue to next credential

                except ConnectTimeoutError as e:
                    # Timeout - retry if attempts remaining, otherwise abort
                    if retries_remaining > 0:
                        retries_remaining -= 1
                        logger.warning(
                            f"Timeout connecting to {self.device.name}, "
                            f"retrying ({retries_remaining} retries left)"
                        )
                        continue  # Retry same credential
                    # No retries left - raise timeout error
                    logger.error(
                        f"Connection timeout after {CONNECTION_TIMEOUT}s for {self.device.name} "
                        "(retries exhausted)"
                    )
                    raise TimeoutError(
                        f"SSH timeout after {CONNECTION_TIMEOUT}s connecting to {self.device.name} "
                        "(retries exhausted)",
                        e
                    )

                except ConnectionException as e:
                    # Network error - abort immediately (no retry, no credential fallback)
                    logger.error(
                        f"Connection failed for {self.device.name}: {e}"
                    )
                    raise ConnectionError(
                        f"Connection failed for {self.device.name}: {e}",
                        e
                    )

        # All credentials exhausted without success
        raise AuthenticationError(
            f"Tried {len(credential_sets)} credential set(s) for {self.device.name}, "
            "all failed authentication"
        )

    def disconnect(self):
        """
        Close the NAPALM connection if open.

        Safe to call multiple times - only closes if connection exists.
        Logs warning if close fails but doesn't raise exception.
        """
        if self._driver_instance and self.connected:
            try:
                self._driver_instance.close()
            except Exception as e:
                logger.warning(
                    f"Error closing connection to {self.device.name}: {e}"
                )
            finally:
                self.connected = False
                self._driver_instance = None

    def get_driver(self):
        """
        Get the connected NAPALM driver instance.

        Returns:
            NAPALM driver instance (e.g., IOSDriver, JunOSDriver)

        Note:
            Only valid after successful connect(). Used by facts collection
            to call NAPALM methods like get_facts().
        """
        return self._driver_instance

    def __enter__(self):
        """
        Context manager entry - establishes connection.

        Returns:
            self: DeviceConnector instance with active connection

        Note:
            Use with device_facts parameter if needed:
            connector = DeviceConnector(device)
            with connector:
                connector.connect(device_facts)
                # use connector
        """
        # Note: connect() must be called separately to pass device_facts parameter
        # The context manager ensures cleanup, but caller controls when to connect
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit - ensures connection cleanup.

        This method provides finally-block semantics per SSH-05 requirement:
        disconnect() is ALWAYS called regardless of whether an exception occurred
        in the with block, ensuring SSH connections are properly closed.

        Args:
            exc_type: Exception type if exception occurred, None otherwise
            exc_val: Exception value if exception occurred, None otherwise
            exc_tb: Exception traceback if exception occurred, None otherwise

        Returns:
            False: Don't suppress exceptions - let them propagate to caller
        """
        # ALWAYS disconnect regardless of exception state (finally-block semantics)
        self.disconnect()
        # Don't suppress exceptions - let caller handle them
        return False
