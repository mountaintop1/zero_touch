from django.urls import include, path

from . import views

app_name = "netbox_network_ops"

urlpatterns = [
    path("", views.DeviceSelectionView.as_view(), name="device_selection"),
    path("device/<int:pk>/collect/", views.CollectFactsView.as_view(), name="collect_facts"),
    path("device/<int:pk>/", views.DeviceFactsView.as_view(), name="device_facts"),
    path("api/", include("netbox_network_ops.api.urls")),
]
