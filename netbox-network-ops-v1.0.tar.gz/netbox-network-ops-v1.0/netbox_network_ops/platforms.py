"""
Platform detection and driver mapping for network devices.

Maps NetBox platform slugs to NAPALM driver names, providing helpful
error messages for unknown or unsupported platforms.
"""

import difflib
from .exceptions import PlatformError


# Mapping from NetBox platform slug to NAPALM driver name
PLATFORM_DRIVER_MAP = {
    'cisco_ios': 'ios',
    'cisco_iosxe': 'ios',  # IOS-XE uses the same driver as IOS
    'cisco_nxos': 'nxos_ssh',  # SSH-only driver for NX-OS (matches working pattern from IOS/JunOS)
    'juniper_junos': 'junos',
}


def get_driver_for_platform(platform_slug):
    """
    Get NAPALM driver name for a NetBox platform slug.

    Args:
        platform_slug: Platform slug from NetBox device (e.g., 'ios', 'junos')

    Returns:
        str: NAPALM driver name (e.g., 'ios', 'junos')

    Raises:
        PlatformError: If platform is None/empty or not supported
    """
    # Check for None or empty platform
    if not platform_slug:
        raise PlatformError(
            "Device has no platform assigned in NetBox. "
            "Please assign a platform to this device."
        )

    # Normalize to lowercase for lookup
    normalized_slug = platform_slug.lower()

    # Check if platform is supported
    if normalized_slug in PLATFORM_DRIVER_MAP:
        return PLATFORM_DRIVER_MAP[normalized_slug]

    # Platform not found - try to suggest similar platform
    supported_platforms = list(PLATFORM_DRIVER_MAP.keys())
    close_matches = difflib.get_close_matches(
        normalized_slug,
        supported_platforms,
        n=1,
        cutoff=0.6
    )

    if close_matches:
        suggestion = close_matches[0]
        raise PlatformError(
            f"Platform '{platform_slug}' not supported. "
            f"Did you mean '{suggestion}'? "
            f"Supported: {', '.join(supported_platforms)}"
        )
    else:
        raise PlatformError(
            f"Platform '{platform_slug}' not supported. "
            f"Supported platforms: {', '.join(supported_platforms)}"
        )
