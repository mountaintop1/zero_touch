"""
Device facts collection service.

Provides the main facts collection entry point (collect_facts) that orchestrates
device connection, facts retrieval, extraction, and database storage with atomic
transaction handling.

This is the core engine that Phase 5 (background jobs) and Phase 7 (UI) will call
to collect facts. It integrates all components from Phase 3 (connection) and
Phase 4 Plan 01 (model + extraction).
"""

import logging
from enum import Enum
from typing import Tuple, Optional
from django.db import transaction
from django.utils import timezone

from .models import DeviceFacts, CollectionStatusChoices
from .connection import DeviceConnector
from .exceptions import (
    ConnectionError, AuthenticationError, TimeoutError,
    PlatformError, UnsupportedPlatformError
)
from .facts_extraction import extract_facts
from .error_messages import get_user_friendly_message, sanitize_error_message

logger = logging.getLogger(__name__)


class CollectionStatus(Enum):
    """Status enumeration for facts collection results."""
    SUCCESS = 'success'
    FAILED = 'failed'
    PENDING = 'pending'


# Supported platform slugs for facts collection
SUPPORTED_PLATFORMS = ['cisco_ios', 'cisco_iosxe', 'cisco_nxos', 'juniper_junos']


@transaction.atomic
def _save_facts_atomically(device, facts_data: dict) -> DeviceFacts:
    """
    Save facts record and update is_current flags atomically.

    Ensures database consistency:
    - Old records marked non-current
    - New record created with is_current=True
    - Both happen or neither happens (transaction rollback on error)

    Args:
        device: NetBox Device object
        facts_data: Dictionary with extracted facts (hostname, vendor, model, serial_number, os_version)

    Returns:
        DeviceFacts: Newly created facts record with is_current=True

    Side effects:
        - Updates is_current=False for all existing facts records for this device
        - Creates new DeviceFacts record with collection_status=SUCCESS
        - Sets last_collected to current time
    """
    # Mark all existing records as non-current
    DeviceFacts.objects.filter(
        device=device,
        is_current=True
    ).update(is_current=False)

    # Create new current record
    facts = DeviceFacts(
        device=device,
        is_current=True,
        collection_status=CollectionStatusChoices.STATUS_SUCCESS,
        last_collected=timezone.now(),
        hostname=facts_data.get('hostname', ''),
        vendor=facts_data.get('vendor', ''),
        model=facts_data.get('model', ''),
        serial_number=facts_data.get('serial_number', ''),
        os_version=facts_data.get('os_version', ''),
    )

    # Validate before saving (calls Model.clean() for normalization)
    facts.full_clean()
    facts.save()

    logger.info(f"Saved facts for {device.name}")

    return facts


@transaction.atomic
def _save_failed_record(device, error_message: str) -> DeviceFacts:
    """
    Create failed collection record with error message.

    Marks existing records as non-current and creates new record with
    collection_status=FAILED and error message.

    Args:
        device: NetBox Device object
        error_message: User-friendly error message (truncated to 500 chars)

    Returns:
        DeviceFacts: Newly created failed facts record
    """
    # Mark all existing records as non-current
    DeviceFacts.objects.filter(
        device=device,
        is_current=True
    ).update(is_current=False)

    # Sanitize and truncate error message to avoid database field overflow and credential exposure
    truncated_message = sanitize_error_message(error_message)[:500]

    # Create failed record
    facts = DeviceFacts.objects.create(
        device=device,
        is_current=True,
        collection_status=CollectionStatusChoices.STATUS_FAILED,
        error_message=truncated_message,
        last_collected=timezone.now(),
    )

    logger.info(f"Recorded failed collection for {device.name}")

    return facts


def collect_facts(device) -> Tuple[CollectionStatus, Optional[DeviceFacts]]:
    """
    Collect device facts via NAPALM and store in database.

    This is the main entry point for facts collection. It:
    1. Validates device platform is supported
    2. Connects to device using DeviceConnector (with credential fallback)
    3. Retrieves raw facts from NAPALM driver.get_facts()
    4. Extracts and normalizes facts using platform-specific extractors
    5. Saves facts atomically to database
    6. Updates credential memory for faster future connections

    Connection happens OUTSIDE transaction to avoid holding database locks
    during slow SSH operations. Only database updates are inside transaction.

    Args:
        device: NetBox Device object with primary_ip4 and platform

    Returns:
        Tuple of (CollectionStatus, Optional[DeviceFacts]):
        - (CollectionStatus.SUCCESS, facts_record) on success
        - (CollectionStatus.FAILED, None) on failure (failed record created in DB)

    Raises:
        UnsupportedPlatformError: If device has no platform or platform not in SUPPORTED_PLATFORMS

    Side effects:
        - Creates DeviceFacts record (success or failed)
        - Updates successful_credential_index on facts record if credential changed
        - Logs collection attempts (without exposing credentials)

    Examples:
        >>> status, facts = collect_facts(device)
        >>> if status == CollectionStatus.SUCCESS:
        ...     print(f"Collected facts: {facts.hostname}")
        ... else:
        ...     print(f"Collection failed: {facts.error_message}")
    """
    # Validate platform exists and is supported
    if device.platform is None:
        raise UnsupportedPlatformError(
            f"Device {device.name} has no platform assigned",
            None
        )

    platform_slug = device.platform.slug
    if platform_slug not in SUPPORTED_PLATFORMS:
        raise UnsupportedPlatformError(
            f"Platform '{platform_slug}' is not supported for facts collection. "
            f"Supported platforms: {', '.join(SUPPORTED_PLATFORMS)}",
            None
        )

    # Get existing facts for credential memory optimization
    existing_facts = DeviceFacts.objects.filter(
        device=device,
        is_current=True
    ).first()

    try:
        # Connect and retrieve facts (OUTSIDE transaction - no DB locks during SSH)
        with DeviceConnector(device) as connector:
            credential_index = connector.connect(device_facts=existing_facts)
            driver = connector.get_driver()
            raw_facts = driver.get_facts()

        # Extract and normalize facts (pure function, fast)
        normalized_facts = extract_facts(raw_facts, platform_slug)

        # Save to database atomically (INSIDE transaction, fast)
        facts_record = _save_facts_atomically(device, normalized_facts)

        # Update credential memory if credential changed
        if credential_index != (existing_facts.successful_credential_index if existing_facts else None):
            facts_record.successful_credential_index = credential_index
            facts_record.save(update_fields=['successful_credential_index'])

        logger.info(f"Facts collected successfully for {device.name}")
        return (CollectionStatus.SUCCESS, facts_record)

    except AuthenticationError as e:
        # All credentials failed authentication
        error_msg = get_user_friendly_message(e)
        _save_failed_record(device, error_msg)
        logger.error(f"Facts collection failed for {device.name}: {error_msg}")
        return (CollectionStatus.FAILED, None)

    except TimeoutError as e:
        # Device unreachable - connection timed out
        error_msg = get_user_friendly_message(e)
        _save_failed_record(device, error_msg)
        logger.error(f"Facts collection failed for {device.name}: {error_msg}")
        return (CollectionStatus.FAILED, None)

    except ConnectionError as e:
        # Network/connection error
        error_msg = get_user_friendly_message(e)
        _save_failed_record(device, error_msg)
        logger.error(f"Facts collection failed for {device.name}: {error_msg}")
        return (CollectionStatus.FAILED, None)

    except PlatformError as e:
        # Platform configuration error
        error_msg = get_user_friendly_message(e)
        _save_failed_record(device, error_msg)
        logger.error(f"Facts collection failed for {device.name}: {error_msg}")
        return (CollectionStatus.FAILED, None)

    except UnsupportedPlatformError:
        # Re-raise unsupported platform errors - don't create failed record
        # Caller should handle these as configuration errors, not collection failures
        raise

    except Exception as e:
        # Unexpected error - log full exception for debugging
        error_msg = get_user_friendly_message(e)
        _save_failed_record(device, error_msg)
        logger.exception(f"Unexpected error collecting facts for {device.name}: {e}")
        return (CollectionStatus.FAILED, None)
