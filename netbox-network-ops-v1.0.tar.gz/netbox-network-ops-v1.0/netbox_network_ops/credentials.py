"""
Credential loading and management for NetBox Network Operations plugin.

Loads credentials from environment variables (NETOPS_USERNAME_1/2/3 and
NETOPS_PASSWORD_1/2/3) and provides access to valid credential sets for
SSH authentication with fallback support.
"""

import os
import logging
from django.core.exceptions import ImproperlyConfigured

logger = logging.getLogger(__name__)

# Module-level storage for credential sets
# Each tuple contains (username, password)
CREDENTIAL_SETS = []


def load_from_environment():
    """
    Load credential sets from environment variables.

    Reads NETOPS_USERNAME_{1,2,3} and NETOPS_PASSWORD_{1,2,3} from environment.
    Only complete pairs (both username and password present) are stored.

    Raises:
        ImproperlyConfigured: If no valid credential sets are found (primary
                            credentials missing or incomplete).

    Note:
        Incomplete credential sets (username without password or vice versa)
        are silently skipped. Django system checks will produce warnings for
        incomplete sets.
    """
    global CREDENTIAL_SETS
    CREDENTIAL_SETS = []

    # Load up to 3 credential sets
    for i in range(1, 4):
        username = os.environ.get(f'NETOPS_USERNAME_{i}')
        password = os.environ.get(f'NETOPS_PASSWORD_{i}')

        # Only add complete credential sets
        if username and password:
            CREDENTIAL_SETS.append((username, password))
        # Incomplete sets are skipped silently - checks.py will warn

    # Require at least one valid credential set (primary credentials)
    if not CREDENTIAL_SETS:
        raise ImproperlyConfigured(
            "No valid credential sets found. At least NETOPS_USERNAME_1 and "
            "NETOPS_PASSWORD_1 must be set in environment variables."
        )

    logger.info(f"Loaded {len(CREDENTIAL_SETS)} credential set(s) from environment")


def get_credential_sets():
    """
    Return all loaded credential sets.

    Returns:
        list: List of (username, password) tuples. Always contains at least
              one tuple if load_from_environment() succeeded.

    Example:
        >>> creds = get_credential_sets()
        >>> for username, password in creds:
        ...     # Try authentication with this credential set
        ...     pass
    """
    return CREDENTIAL_SETS
