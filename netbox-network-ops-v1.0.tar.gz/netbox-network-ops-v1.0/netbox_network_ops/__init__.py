import logging
from netbox.plugins import PluginConfig

logger = logging.getLogger(__name__)


class NetworkOpsConfig(PluginConfig):
    name = 'netbox_network_ops'
    verbose_name = 'Network Operations'
    description = 'Collect and display live device facts from network devices'
    version = '0.1.0'
    base_url = 'network-ops'
    min_version = '4.0.0'

    def ready(self):
        """Initialize plugin: configure logging, load credentials, register checks."""
        super().ready()

        # 1. Configure credential sanitization FIRST (before any credential operations)
        from .logging_filters import configure_logging
        configure_logging()

        # 2. Load credentials from environment
        from .credentials import load_from_environment
        load_from_environment()

        # 3. Import checks module to trigger @register() decorator
        from . import checks


config = NetworkOpsConfig
