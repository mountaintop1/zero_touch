"""
API views for background job status polling.

Provides JSON endpoints for AJAX polling of job progress during
facts collection operations.
"""

from django.http import JsonResponse
from django.views import View
from core.models import Job
import uuid


class JobStatusView(View):
    """
    API endpoint for job status polling.

    Returns JSON with current job status, progress, and messages.
    Called by frontend AJAX every 5 seconds while job is running.

    URL: /api/plugins/network-ops/jobs/<job_id>/status/
    Method: GET

    Response format:
    {
        "job_id": "uuid-string",
        "status": "pending|running|completed|failed|errored",
        "started": "ISO8601 timestamp or null",
        "completed": "ISO8601 timestamp or null",
        "step": "current step name",
        "message": "human-readable progress message",
        "progress": 0-100,
        "error": "error message if failed/errored"
    }
    """

    def get(self, request, job_id):
        # Validate and parse UUID
        try:
            job_uuid = uuid.UUID(job_id)
        except ValueError:
            return JsonResponse({'error': 'Invalid job ID format'}, status=400)

        # Fetch job record
        try:
            job = Job.objects.get(job_id=job_uuid)
        except Job.DoesNotExist:
            return JsonResponse({'error': 'Job not found'}, status=404)

        # Build response
        response_data = {
            'job_id': str(job.job_id),
            'status': job.status,
            'started': job.started.isoformat() if job.started else None,
            'completed': job.completed.isoformat() if job.completed else None,
        }

        # Include progress data from job.data if available
        if job.data:
            response_data.update({
                'step': job.data.get('step', ''),
                'message': job.data.get('message', ''),
                'progress': job.data.get('progress', 0),
            })
        else:
            response_data.update({
                'step': '',
                'message': '',
                'progress': 0,
            })

        # Include error info for failed/errored jobs
        if job.status in ('failed', 'errored'):
            response_data['error'] = job.error or job.data.get('message', '') if job.data else ''
            # Include traceback for debugging (only in job.data, not exposed to regular error)
            if job.data and 'traceback' in job.data:
                response_data['traceback'] = job.data['traceback']

        return JsonResponse(response_data)
