"""
API URL routing for background job endpoints.
"""

from django.urls import path
from . import views

urlpatterns = [
    path(
        'jobs/<str:job_id>/status/',
        views.JobStatusView.as_view(),
        name='job_status'
    ),
]
