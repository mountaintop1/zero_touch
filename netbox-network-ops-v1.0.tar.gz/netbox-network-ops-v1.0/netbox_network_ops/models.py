"""
NetBox Network Operations Plugin Models
"""
from django.db import models
from django.urls import reverse
from netbox.models import NetBoxModel
from utilities.choices import ChoiceSet


class CollectionStatusChoices(ChoiceSet):
    """Status choices for device facts collection."""

    key = 'DeviceFacts.collection_status'

    STATUS_SUCCESS = 'success'
    STATUS_FAILED = 'failed'
    STATUS_PENDING = 'pending'

    CHOICES = [
        (STATUS_SUCCESS, 'Success', 'green'),
        (STATUS_FAILED, 'Failed', 'red'),
        (STATUS_PENDING, 'Pending', 'orange'),
    ]


class DeviceFacts(NetBoxModel):
    """
    Stores facts collected from a network device via NAPALM.

    This model maintains a many-to-one relationship with NetBox's Device model,
    supporting historical tracking of facts over time. The is_current flag marks
    the latest facts record for each device.
    """

    device = models.ForeignKey(
        to='dcim.Device',
        on_delete=models.CASCADE,
        related_name='facts_history',
        help_text='Associated NetBox device'
    )
    is_current = models.BooleanField(
        default=True,
        help_text='Whether this is the current/latest facts record'
    )
    collected_at = models.DateTimeField(
        auto_now_add=True,
        help_text='When this specific collection occurred'
    )
    hostname = models.CharField(
        max_length=255,
        blank=True,
        help_text='Hostname reported by the device'
    )
    vendor = models.CharField(
        max_length=100,
        blank=True,
        help_text='Device vendor/manufacturer'
    )
    model = models.CharField(
        max_length=100,
        blank=True,
        help_text='Device model'
    )
    serial_number = models.CharField(
        max_length=100,
        blank=True,
        help_text='Device serial number'
    )
    os_version = models.CharField(
        max_length=100,
        blank=True,
        help_text='Operating system version'
    )
    collection_status = models.CharField(
        max_length=20,
        choices=CollectionStatusChoices,
        default=CollectionStatusChoices.STATUS_PENDING,
        help_text='Status of the last facts collection attempt'
    )
    last_collected = models.DateTimeField(
        null=True,
        blank=True,
        help_text='Timestamp of last successful collection'
    )
    error_message = models.TextField(
        blank=True,
        help_text='Error message from failed collection'
    )
    successful_credential_index = models.IntegerField(
        null=True,
        blank=True,
        help_text='Index (1-3) of credential set that last succeeded'
    )

    class Meta:
        verbose_name = 'Device Facts'
        verbose_name_plural = 'Device Facts'
        ordering = ['-collected_at']
        indexes = [
            models.Index(fields=['device', 'is_current'], name='netops_current_idx'),
            models.Index(fields=['device', 'collected_at'], name='netops_history_idx'),
            models.Index(fields=['collection_status'], name='netops_status_idx'),
            models.Index(fields=['last_collected'], name='netops_collected_idx'),
        ]

    def __str__(self):
        status = "Current" if self.is_current else "Historical"
        return f"{status} Facts: {self.device.name}"

    def get_absolute_url(self):
        return reverse('plugins:netbox_network_ops:devicefacts', args=[self.pk])

    def get_collection_status_color(self):
        """Get the color associated with the current collection status."""
        return CollectionStatusChoices.colors.get(self.collection_status)

    def get_status_badge_class(self):
        """Get Bootstrap badge class for collection status."""
        color_map = {
            'green': 'success',
            'red': 'danger',
            'orange': 'warning',
        }
        raw_color = self.get_collection_status_color()
        return color_map.get(raw_color, 'secondary')
