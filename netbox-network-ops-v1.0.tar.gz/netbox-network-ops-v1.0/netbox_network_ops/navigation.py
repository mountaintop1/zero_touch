from netbox.plugins import PluginMenuItem

menu_items = (
    PluginMenuItem(
        link="plugins:netbox_network_ops:device_selection",
        link_text="Device Facts",
    ),
)
