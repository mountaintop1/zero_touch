"""
Background job infrastructure for facts collection.

Provides FactsCollectionJob (JobRunner subclass) that executes facts collection
asynchronously in background workers, and trigger_facts_collection() helper for
enqueuing jobs with retry configuration.

This prevents HTTP workers from blocking during SSH connections.
Phase 8 views will call trigger_facts_collection() when user clicks "Collect Facts".
"""

import logging
from typing import Dict

from core.exceptions import JobFailed
from netbox.jobs import JobRunner

from .exceptions import UnsupportedPlatformError
from .facts_collection import CollectionStatus, collect_facts

logger = logging.getLogger(__name__)


class FactsCollectionJob(JobRunner):
    """
    Background job for collecting device facts via NAPALM.

    This job:
    - Retrieves device from self.job.object
    - Updates progress at each step via job.data
    - Calls collect_facts() to execute collection
    - Handles expected failures (auth, timeout) vs unexpected errors
    - Marks job as 'failed' for expected failures, 'errored' for config issues

    Progress tracking:
    - initializing (0%): Starting facts collection
    - connecting (25%): Connecting to device
    - retrieving (50%): Retrieving device facts
    - saving (75%): Saving facts to database
    - completed (100%): Facts collected successfully (success)
    - failed (100%): Error message (expected failure)

    Job lifecycle:
    - Enqueued: User clicked "Collect Facts" button
    - Started: RQ worker picked up job
    - Progress: Updates visible in NetBox Jobs UI
    - Completed: Facts saved, job marked complete
    - Failed: Auth/timeout/network error, job marked failed
    - Errored: Config issue (unsupported platform), job marked errored
    """

    class Meta:
        name = "Facts Collection"

    def run(self, *args, **kwargs):
        """
        Execute facts collection in background worker.

        This is called by RQ worker when job is picked from queue.
        Device is retrieved from self.job.object (the associated NetBox object).

        Progress updates are stored in self.job.data and persisted to database
        via save(), making them visible in NetBox Jobs UI.

        Returns:
            None on success (job marked complete)

        Raises:
            JobFailed: For expected failures (auth, timeout, network) - marks job as 'failed'
            UnsupportedPlatformError: For config issues - marks job as 'errored'
            Exception: For unexpected errors (stored in job.data before re-raising)
        """
        # Retrieve device from job object
        device = self.job.object

        # Handle case where device was deleted after job was enqueued
        if device is None:
            self._update_progress("failed", "Device no longer exists", 100)
            raise JobFailed("Device was deleted before facts collection could run")

        self.logger.info(f"Starting facts collection for device: {device.name}")

        try:
            # Step 1: Initializing (0%)
            self._update_progress("initializing", "Starting facts collection...", 0)

            # Step 2: Connecting (25%)
            self._update_progress("connecting", f"Connecting to {device.name}...", 25)

            # Step 3: Retrieving (50%)
            self._update_progress("retrieving", "Retrieving device facts...", 50)

            # Execute facts collection (handles connection, retrieval, extraction, saving)
            status, facts = collect_facts(device)

            # Step 4: Saving (75%) - happens inside collect_facts, but show progress
            self._update_progress("saving", "Saving facts to database...", 75)

            # Step 5: Handle result
            if status == CollectionStatus.SUCCESS:
                # Success: mark complete
                self._update_progress("completed", "Facts collected successfully", 100)
                self.logger.info(f"Facts collection completed for {device.name}")
                return  # Job marked as complete

            elif status == CollectionStatus.FAILED:
                # Expected failure (auth, timeout, network): mark as failed
                error_msg = facts.error_message if facts else "Facts collection failed"
                self._update_progress("failed", error_msg, 100)
                self.logger.error(
                    f"Facts collection failed for {device.name}: {error_msg}"
                )
                raise JobFailed(error_msg)

        except UnsupportedPlatformError as e:
            # Configuration error: let it propagate unchanged
            # This marks job as 'errored' (not 'failed') - indicates config issue
            self._update_progress("failed", str(e), 100)
            self.logger.error(f"Unsupported platform for {device.name}: {e}")
            raise

        except Exception as e:
            # Unexpected error: store traceback in job.data for debugging
            self.logger.exception(
                f"Unexpected error collecting facts for {device.name}: {e}"
            )

            # Store error details for debugging
            self.job.data = {
                "step": "failed",
                "message": f"Unexpected error: {str(e)}",
                "progress": 100,
                "error_type": type(e).__name__,
                "error_details": str(e),
            }
            self.job.save()

            # Re-raise to mark job as 'errored'
            raise

    def _update_progress(self, step: str, message: str, progress: int):
        """
        Update job progress and persist to database.

        This makes progress visible in NetBox Jobs UI in real-time.

        Args:
            step: Current step name (initializing, connecting, retrieving, saving, completed, failed)
            message: User-friendly progress message
            progress: Percentage complete (0-100)

        Side effects:
            - Updates self.job.data with progress information
            - Calls self.job.save() to persist immediately to database
        """
        self.job.data = {"step": step, "message": message, "progress": progress}
        self.job.save()


def trigger_facts_collection(device, user) -> Dict[str, str]:
    """
    Enqueue a facts collection job for the specified device.

    This is the entry point that Phase 8 views will call when user clicks
    "Collect Facts" button. It enqueues the job and returns job metadata
    for displaying to user.

    Note: Job lifecycle and failure handling is managed by NetBox's job
    infrastructure. Manual retry can be triggered by the user if needed.

    Args:
        device: NetBox Device object to collect facts from
        user: NetBox User object (the requesting user)

    Returns:
        Dictionary with:
        - job_id: str - UUID as string (for JSON serialization)
        - status: str - Always 'pending' when enqueued
        - device_name: str - Device name for display

    Examples:
        >>> result = trigger_facts_collection(device, request.user)
        >>> print(result)
        {'job_id': '123e4567-e89b-12d3-a456-426614174000', 'status': 'pending', 'device_name': 'router1'}

        >>> # View can redirect to job detail page
        >>> return redirect('job_detail', job_id=result['job_id'])
    """
    # Enqueue job (NetBox manages job lifecycle and retries)
    job = FactsCollectionJob.enqueue(
        instance=device,  # The NetBox Device object
        user=user,  # The requesting user
    )

    logger.info(f"Enqueued facts collection job {job.job_id} for device {device.name}")

    # Return job metadata as dict (not Job object) for clean interface
    return {
        "job_id": str(job.job_id),  # UUID as string for JSON serialization
        "status": "pending",
        "device_name": device.name,
    }
