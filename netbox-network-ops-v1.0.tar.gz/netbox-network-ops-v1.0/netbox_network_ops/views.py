from django.views.generic import FormView, TemplateView
from django.shortcuts import redirect
from django.http import JsonResponse
from django.views import View
from django.utils import timezone
from datetime import timedelta
from django.contrib.contenttypes.models import ContentType
from core.models import Job
from dcim.models import Device

from .forms import DeviceSelectionForm
from .models import DeviceFacts, CollectionStatusChoices
from .jobs import trigger_facts_collection


# Staleness and stale job thresholds
STALENESS_THRESHOLD = timedelta(hours=24)
STALE_JOB_THRESHOLD = timedelta(minutes=10)


def normalize_for_comparison(value):
    """
    Normalize a string value for comparison.

    Handles:
    - Case normalization (lowercase)
    - Whitespace stripping
    - Vendor name variations (Cisco Systems -> cisco, Juniper Networks -> juniper)
    - None/empty values

    Args:
        value: String to normalize, or None

    Returns:
        Normalized lowercase string, or empty string if None
    """
    if value is None or value == '':
        return ''

    # Lowercase and strip whitespace
    normalized = str(value).lower().strip()

    # Map vendor variations to canonical form
    vendor_mappings = {
        'cisco systems': 'cisco',
        'juniper networks': 'juniper',
        'arista networks': 'arista',
        'hewlett packard': 'hp',
        'hewlett-packard': 'hp',
    }

    # Apply vendor mapping if present
    return vendor_mappings.get(normalized, normalized)


class DeviceSelectionView(FormView):
    """View for device selection interface."""

    template_name = 'netbox_network_ops/device_selection.html'
    form_class = DeviceSelectionForm

    def get_form_kwargs(self):
        """Pass region_id from GET params to form."""
        kwargs = super().get_form_kwargs()
        kwargs['region_id'] = self.request.GET.get('region')
        return kwargs

    def get_context_data(self, **kwargs):
        """Add device count and availability to context."""
        context = super().get_context_data(**kwargs)

        # Get filtered device queryset from form
        form = context['form']
        device_queryset = form.fields['device'].queryset

        # Provide count for template display
        context['device_count'] = device_queryset.count()
        context['has_devices'] = device_queryset.exists()
        context['total_devices'] = Device.objects.filter(
            primary_ip4__isnull=False
        ).count()

        return context

    def form_valid(self, form):
        """Redirect to device facts page after selection."""
        device = form.cleaned_data['device']
        # Redirect using plugin namespace
        return redirect(
            'plugins:netbox_network_ops:device_facts',
            pk=device.pk
        )


class DeviceFactsView(TemplateView):
    """
    Device Facts detail page.

    Loads device object from URL parameter, retrieves current facts,
    computes field mismatches between NetBox data and device facts,
    and passes all data to template context.
    """
    template_name = 'netbox_network_ops/device_facts.html'

    def get_context_data(self, **kwargs):
        """Load device, facts, and compute mismatches."""
        context = super().get_context_data(**kwargs)
        pk = self.kwargs['pk']

        # Load device with related objects for performance
        device = Device.objects.select_related(
            'device_type__manufacturer',
            'platform',
            'site',
            'role',
            'primary_ip4'
        ).get(pk=pk)
        context['device'] = device

        # Load current DeviceFacts
        facts = DeviceFacts.objects.filter(
            device=device,
            is_current=True
        ).first()
        context['facts'] = facts

        # Add explicit error flag for template simplicity
        context['has_error'] = (
            facts is not None and
            facts.collection_status == CollectionStatusChoices.STATUS_FAILED
        )

        # Compute mismatches only if facts exist and collection was successful
        if facts and facts.collection_status == CollectionStatusChoices.STATUS_SUCCESS:
            mismatches = self._compute_mismatches(device, facts)
            context['mismatches'] = mismatches
            context['mismatch_count'] = sum(mismatches.values())
        else:
            context['mismatches'] = {}
            context['mismatch_count'] = 0

        # Calculate staleness for display
        if facts and facts.last_collected:
            age = timezone.now() - facts.last_collected
            context['is_stale'] = age > STALENESS_THRESHOLD
            context['facts_age_days'] = age.days
        else:
            context['is_stale'] = False
            context['facts_age_days'] = 0

        # Check for active collection job
        has_active_job, active_job_id = self._check_active_job(device)
        context['has_active_job'] = has_active_job
        context['active_job_id'] = active_job_id

        # Determine if auto-collection should trigger (first-time visitors)
        context['should_auto_collect'] = (
            facts is None and  # No facts exist
            not has_active_job  # No job running
        )

        # If current facts show failure, also load last successful facts
        if facts and facts.collection_status == CollectionStatusChoices.STATUS_FAILED:
            context['last_successful_facts'] = DeviceFacts.objects.filter(
                device=device,
                collection_status=CollectionStatusChoices.STATUS_SUCCESS
            ).order_by('-last_collected').first()

        return context

    def _check_active_job(self, device):
        """
        Check for active (non-stale) collection job for this device.

        Returns:
            Tuple of (has_active_job: bool, job_id: str or None)

        Stale jobs (running >10 minutes) are ignored and allow new collection.
        """
        device_ct = ContentType.objects.get_for_model(device)

        active_job = Job.objects.filter(
            object_type=device_ct,
            object_id=device.pk,
            name='Facts Collection',
            status__in=['pending', 'running']
        ).order_by('-created').first()

        if not active_job:
            return (False, None)

        # Check if job is stale (stuck >10 minutes)
        if active_job.status == 'running' and active_job.started:
            job_age = timezone.now() - active_job.started
            if job_age > STALE_JOB_THRESHOLD:
                return (False, None)  # Stale job, allow new collection

        return (True, str(active_job.job_id))

    def _compute_mismatches(self, device, facts):
        """
        Compare NetBox device data with collected facts.

        Compares:
        - name: device.name vs facts.hostname
        - manufacturer: device.device_type.manufacturer.name vs facts.vendor
        - model: device.device_type.model vs facts.model

        Args:
            device: Device object with select_related data
            facts: DeviceFacts object with collected data

        Returns:
            dict: {field_name: bool} where True indicates a mismatch
        """
        mismatches = {}

        # Compare hostname
        netbox_name = normalize_for_comparison(device.name)
        facts_hostname = normalize_for_comparison(facts.hostname)
        mismatches['name'] = netbox_name != facts_hostname

        # Compare manufacturer
        netbox_manufacturer = normalize_for_comparison(
            device.device_type.manufacturer.name if device.device_type else None
        )
        facts_vendor = normalize_for_comparison(facts.vendor)
        mismatches['manufacturer'] = netbox_manufacturer != facts_vendor

        # Compare model
        netbox_model = normalize_for_comparison(
            device.device_type.model if device.device_type else None
        )
        facts_model = normalize_for_comparison(facts.model)
        mismatches['model'] = netbox_model != facts_model

        return mismatches


class CollectFactsView(View):
    """
    API endpoint to trigger facts collection for a device.

    POST /plugins/network-ops/device/<pk>/collect/

    Returns JSON with job_id for frontend polling.
    """

    def post(self, request, pk):
        try:
            device = Device.objects.get(pk=pk)
        except Device.DoesNotExist:
            return JsonResponse({'error': 'Device not found'}, status=404)

        # Trigger background job
        result = trigger_facts_collection(device, request.user)

        return JsonResponse({
            'job_id': result['job_id'],
            'status': result['status'],
            'device_name': result['device_name']
        })
