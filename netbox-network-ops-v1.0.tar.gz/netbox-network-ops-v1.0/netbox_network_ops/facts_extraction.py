"""
Platform-specific facts extraction from NAPALM responses.

Provides extraction functions that handle platform-specific quirks (e.g., JunOS
None hostname issue on stacked switches) and normalize vendor names for consistent
comparison in the UI.

NAPALM's get_facts() method returns 8 fields:
- hostname, fqdn, vendor, model, serial_number, os_version, uptime, interface_list

We extract only the 5 required fields for DeviceFacts:
- hostname, vendor, model, serial_number, os_version
"""


def normalize_vendor(vendor):
    """
    Normalize vendor names for consistent comparison.

    Maps common vendor variations to canonical names for UI consistency.
    For example, "Cisco Systems" becomes "Cisco" for cleaner display and
    easier comparison.

    Args:
        vendor: Raw vendor string from NAPALM get_facts()

    Returns:
        Normalized vendor name (str), or empty string if vendor is None/empty

    Examples:
        >>> normalize_vendor('Cisco Systems')
        'Cisco'
        >>> normalize_vendor('Juniper Networks')
        'Juniper'
        >>> normalize_vendor('Arista')
        'Arista'
        >>> normalize_vendor(None)
        ''
    """
    if not vendor:
        return ''

    # Strip whitespace
    vendor = vendor.strip()

    # Map common vendor variations to canonical names
    vendor_mapping = {
        'Cisco Systems': 'Cisco',
        'Juniper Networks': 'Juniper',
    }

    return vendor_mapping.get(vendor, vendor)


def extract_ios_facts(raw_facts):
    """
    Extract facts from Cisco IOS/IOS-XE get_facts() response.

    Handles standard NAPALM format with None-safe extraction.

    Args:
        raw_facts: Dictionary returned by NAPALM get_facts() method

    Returns:
        Dictionary with extracted and normalized facts:
        {
            'hostname': str,
            'vendor': str,
            'model': str,
            'serial_number': str,
            'os_version': str
        }
    """
    return {
        'hostname': (raw_facts.get('hostname') or '').strip(),
        'vendor': (raw_facts.get('vendor') or '').strip(),
        'model': (raw_facts.get('model') or '').strip(),
        'serial_number': (raw_facts.get('serial_number') or '').strip(),
        'os_version': (raw_facts.get('os_version') or '').strip(),
    }


def extract_junos_facts(raw_facts):
    """
    Extract facts from Juniper JunOS get_facts() response.

    Special handling for JunOS stacked switches where hostname and fqdn
    can be None when RE0 (routing engine 0) is not in position 0.
    This is a known NAPALM issue (GitHub issue #974).

    Args:
        raw_facts: Dictionary returned by NAPALM get_facts() method

    Returns:
        Dictionary with extracted and normalized facts:
        {
            'hostname': str,
            'vendor': str,
            'model': str,
            'serial_number': str,
            'os_version': str
        }

    Note:
        JunOS stacked switches may return None for hostname/fqdn when RE0
        is not in position 0. We handle this gracefully by returning empty
        string instead of None to avoid downstream issues.
    """
    # Handle known JunOS stack issue where hostname can be None
    hostname = raw_facts.get('hostname') or ''

    return {
        'hostname': hostname.strip() if hostname else '',
        'vendor': (raw_facts.get('vendor') or '').strip(),
        'model': (raw_facts.get('model') or '').strip(),
        'serial_number': (raw_facts.get('serial_number') or '').strip(),
        'os_version': (raw_facts.get('os_version') or '').strip(),
    }


def extract_generic_facts(raw_facts):
    """
    Generic facts extraction for platforms without specific handlers.

    Uses standard NAPALM format extraction. This is a fallback for
    platforms that are attempted but don't have dedicated extractors.

    Args:
        raw_facts: Dictionary returned by NAPALM get_facts() method

    Returns:
        Dictionary with extracted and normalized facts:
        {
            'hostname': str,
            'vendor': str,
            'model': str,
            'serial_number': str,
            'os_version': str
        }
    """
    return {
        'hostname': (raw_facts.get('hostname') or '').strip(),
        'vendor': (raw_facts.get('vendor') or '').strip(),
        'model': (raw_facts.get('model') or '').strip(),
        'serial_number': (raw_facts.get('serial_number') or '').strip(),
        'os_version': (raw_facts.get('os_version') or '').strip(),
    }


def extract_facts(raw_facts, platform_slug):
    """
    Extract and normalize facts based on device platform.

    Routes to platform-specific extraction functions to handle platform
    quirks, then applies vendor normalization for consistent UI display.

    Args:
        raw_facts: Dictionary returned by NAPALM get_facts() method
        platform_slug: NetBox platform slug (e.g., 'cisco_ios', 'juniper_junos')

    Returns:
        Dictionary with extracted and normalized facts:
        {
            'hostname': str,
            'vendor': str (normalized),
            'model': str,
            'serial_number': str,
            'os_version': str
        }

    Platform routing:
        - 'cisco_ios', 'cisco_iosxe', 'cisco_nxos' -> extract_ios_facts()
        - 'juniper_junos' -> extract_junos_facts()
        - Others -> extract_generic_facts()

    Examples:
        >>> facts = extract_facts(
        ...     {'hostname': 'R1', 'vendor': 'Cisco Systems', 'model': 'C1000',
        ...      'serial_number': 'ABC123', 'os_version': '15.1'},
        ...     'cisco_ios'
        ... )
        >>> facts['vendor']
        'Cisco'
        >>> facts['hostname']
        'R1'
    """
    # Route to platform-specific extractor
    if platform_slug in ('cisco_ios', 'cisco_iosxe', 'cisco_nxos'):
        extracted = extract_ios_facts(raw_facts)
    elif platform_slug == 'juniper_junos':
        extracted = extract_junos_facts(raw_facts)
    else:
        # Fallback for other platforms
        extracted = extract_generic_facts(raw_facts)

    # Apply vendor normalization
    extracted['vendor'] = normalize_vendor(extracted['vendor'])

    return extracted
