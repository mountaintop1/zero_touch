"""
Error message sanitization and user-friendly message mapping.

Provides utilities to:
1. Strip credentials and sensitive data from error messages before database storage
2. Map exception types to actionable, user-friendly error messages
3. Detect SSH crypto-related errors for specific guidance

Usage:
    from netbox_network_ops.error_messages import (
        sanitize_error_message,
        get_user_friendly_message,
        is_crypto_related_error
    )

    # In exception handler
    try:
        collect_facts(device)
    except AuthenticationError as e:
        error_msg = get_user_friendly_message(e)  # Already sanitized
        save_error(error_msg)

Design:
- sanitize_error_message() removes credentials using regex patterns
- get_user_friendly_message() maps exceptions to actionable messages
- is_crypto_related_error() detects SSH algorithm negotiation failures
- All messages sanitized before returning to prevent credential exposure
- Logs full exception details (sanitized) at DEBUG level for troubleshooting
"""

import logging
import re
from typing import Optional

from .exceptions import (
    AuthenticationError,
    TimeoutError,
    ConnectionError,
    PlatformError,
    UnsupportedPlatformError,
)

logger = logging.getLogger(__name__)


# Regex patterns for sanitizing credentials in error messages
# Based on patterns from logging_filters.py, extended for SSH connection strings
SANITIZATION_PATTERNS = [
    # Match password in key-value format: password=value, password: value, passwd=value, pwd=value
    (r'(password|passwd|pwd)\s*[=:]\s*["\']?([^"\' \n,}]+)', r"\1='******'"),
    # Match username patterns: username=value, user: value, user=value
    (r'(username|user)\s*[=:]\s*["\']?([^"\' \n,}]+)', r"\1='[REDACTED]'"),
    # Match SSH connection strings: ssh://user:pass@host
    (r'ssh://[^@]+:[^@]+@', r'ssh://[REDACTED]:[REDACTED]@'),
    # Match environment variable names containing credentials
    (r'NETOPS_(PASSWORD|USERNAME)_\d+', r'NETOPS_\1_[N]'),
]


def sanitize_error_message(message: Optional[str]) -> str:
    """
    Strip credentials and sensitive data from error message.

    Applies regex patterns to remove:
    - Passwords (password=value, passwd=value, pwd=value)
    - Usernames (username=value, user=value)
    - SSH connection strings (ssh://user:pass@host)
    - Environment variable names containing credentials (NETOPS_PASSWORD_*, NETOPS_USERNAME_*)

    Truncates to 500 characters to prevent database field overflow.

    Args:
        message: Error message string to sanitize (can be None)

    Returns:
        str: Sanitized message truncated to 500 chars, or empty string if input is None

    Examples:
        >>> sanitize_error_message('Failed: password=secret123')
        "Failed: password='******'"
        >>> sanitize_error_message('ssh://admin:pass@10.0.0.1')
        'ssh://[REDACTED]:[REDACTED]@10.0.0.1'
        >>> sanitize_error_message(None)
        ''
    """
    # Handle None input gracefully
    if message is None:
        return ''

    # Convert to string if not already
    if not isinstance(message, str):
        message = str(message)

    # Apply all sanitization patterns with case-insensitive matching
    sanitized = message
    for pattern, replacement in SANITIZATION_PATTERNS:
        sanitized = re.sub(pattern, replacement, sanitized, flags=re.IGNORECASE)

    # Truncate to 500 chars with indicator
    if len(sanitized) > 500:
        sanitized = sanitized[:497] + '...'

    return sanitized


def is_crypto_related_error(exception: Exception) -> bool:
    """
    Detect if exception is SSH algorithm negotiation failure.

    SSH crypto errors occur when client and server cannot agree on encryption
    algorithms (key exchange, host keys, ciphers). These are distinct from
    authentication failures or network errors.

    Checks both the exception message and original_exception (if present) for
    crypto error indicators, since NAPALM ConnectionException wraps the original
    Paramiko exception.

    Args:
        exception: Exception instance to check (typically ConnectionError)

    Returns:
        bool: True if exception indicates SSH crypto negotiation failure

    Indicators:
        - 'key exchange' - Failed KEX algorithm negotiation
        - 'no matching' - No matching algorithms found
        - 'no acceptable' - No acceptable algorithms available
        - 'algorithm negotiation' - Generic algorithm negotiation failure
        - 'incompatible ssh peer' - SSH version or algorithm mismatch
        - 'kex' - Key exchange specific error

    Examples:
        >>> ex = ConnectionError("Unable to negotiate key exchange algorithm")
        >>> is_crypto_related_error(ex)
        True
        >>> ex = ConnectionError("Connection refused")
        >>> is_crypto_related_error(ex)
        False
    """
    # Check exception message
    error_str = str(exception).lower()

    # Also check original_exception if present (NAPALM wraps Paramiko exceptions)
    if hasattr(exception, 'original_exception') and exception.original_exception:
        error_str += ' ' + str(exception.original_exception).lower()

    # Crypto error indicators
    crypto_indicators = [
        'key exchange',
        'no matching',
        'no acceptable',
        'algorithm negotiation',
        'incompatible ssh peer',
        'kex',
    ]

    return any(indicator in error_str for indicator in crypto_indicators)


def get_user_friendly_message(exception: Exception) -> str:
    """
    Map exception type to user-friendly message with actionable guidance.

    Provides specific, actionable error messages based on exception type:
    - AuthenticationError: Guidance on checking environment variable credentials
    - TimeoutError: Guidance on verifying IP address and SSH reachability
    - ConnectionError: Guidance on network connectivity and SSH enablement
    - PlatformError: Guidance on platform assignment in NetBox
    - UnsupportedPlatformError: Keep existing descriptive message
    - Generic Exception: First line of sanitized exception message

    All messages are sanitized before returning to prevent credential exposure.
    Full exception details logged at DEBUG level for troubleshooting.

    Args:
        exception: Exception instance to map to user message

    Returns:
        str: Sanitized, actionable error message suitable for UI display

    Examples:
        >>> get_user_friendly_message(AuthenticationError("Auth failed"))
        'Authentication failed. Verify credentials are correct in environment variables...'
        >>> get_user_friendly_message(TimeoutError("Timeout"))
        'Device unreachable (connection timed out after 30s)...'
    """
    # Log full exception at DEBUG level for troubleshooting (will be sanitized by logging filter)
    logger.debug(f"Converting exception to user message: {type(exception).__name__}: {exception}")

    # Map exception types to actionable messages
    if isinstance(exception, AuthenticationError):
        message = (
            "Authentication failed. Verify credentials are correct in environment variables "
            "(NETOPS_USERNAME_*, NETOPS_PASSWORD_*)."
        )

    elif isinstance(exception, TimeoutError):
        message = (
            "Device unreachable (connection timed out after 30s). Check that the device IP is "
            "correct and the device is reachable via SSH."
        )

    elif isinstance(exception, ConnectionError):
        # Check if this is a crypto-specific error
        if is_crypto_related_error(exception):
            # Extract technical hint (first 150 chars of exception message)
            tech_hint = str(exception)[:150]
            message = (
                "SSH algorithm negotiation failed. The plugin enables legacy algorithms, but the "
                "device may require additional system-level SSH configuration. Check that the device "
                "supports at least one of the enabled SSH algorithms. "
                f"Technical hint: {tech_hint}"
            )
        else:
            # Generic connection error (not auth/timeout/crypto)
            message = (
                "Unable to connect to device. Verify network connectivity and that SSH is enabled "
                "on the device."
            )

    elif isinstance(exception, PlatformError):
        message = (
            "Platform configuration error. Check that the device has a valid platform assigned "
            "in NetBox."
        )

    elif isinstance(exception, UnsupportedPlatformError):
        # Keep existing message - already descriptive with supported platforms list
        message = str(exception)

    else:
        # Generic exception - use first line of exception message
        exception_str = str(exception)
        first_line = exception_str.split('\n')[0] if exception_str else 'Unknown error'
        message = f"Collection failed: {first_line}"

    # Always sanitize before returning
    sanitized_message = sanitize_error_message(message)

    return sanitized_message
