# Generated manually for netbox_network_ops

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('dcim', '__latest__'),
    ]

    operations = [
        migrations.CreateModel(
            name='DeviceFacts',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict, encoder=None)),
                ('hostname', models.CharField(blank=True, help_text='Hostname reported by the device', max_length=255)),
                ('vendor', models.CharField(blank=True, help_text='Device vendor/manufacturer', max_length=100)),
                ('model', models.CharField(blank=True, help_text='Device model', max_length=100)),
                ('serial_number', models.CharField(blank=True, help_text='Device serial number', max_length=100)),
                ('os_version', models.CharField(blank=True, help_text='Operating system version', max_length=100)),
                ('collection_status', models.CharField(
                    default='pending',
                    help_text='Status of the last facts collection attempt',
                    max_length=20,
                    choices=[
                        ('success', 'Success'),
                        ('failed', 'Failed'),
                        ('pending', 'Pending'),
                    ]
                )),
                ('last_collected', models.DateTimeField(blank=True, help_text='Timestamp of last successful collection', null=True)),
                ('error_message', models.TextField(blank=True, help_text='Error message from failed collection')),
                ('device', models.OneToOneField(
                    help_text='Associated NetBox device',
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='facts',
                    to='dcim.device'
                )),
            ],
            options={
                'verbose_name': 'Device Facts',
                'verbose_name_plural': 'Device Facts',
                'ordering': ['device__name'],
            },
        ),
        migrations.AddIndex(
            model_name='devicefacts',
            index=models.Index(fields=['collection_status'], name='netops_status_idx'),
        ),
        migrations.AddIndex(
            model_name='devicefacts',
            index=models.Index(fields=['last_collected'], name='netops_collected_idx'),
        ),
    ]
