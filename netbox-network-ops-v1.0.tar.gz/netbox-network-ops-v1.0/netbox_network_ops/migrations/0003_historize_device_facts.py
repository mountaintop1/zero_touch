# Generated manually for netbox_network_ops plugin
# Phase 04-01: Historize DeviceFacts model

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('netbox_network_ops', '0002_devicefacts_successful_credential_index'),
    ]

    operations = [
        # Change device from OneToOneField to ForeignKey
        migrations.AlterField(
            model_name='devicefacts',
            name='device',
            field=models.ForeignKey(
                help_text='Associated NetBox device',
                on_delete=models.deletion.CASCADE,
                related_name='facts_history',
                to='dcim.device'
            ),
        ),
        # Add is_current boolean flag
        migrations.AddField(
            model_name='devicefacts',
            name='is_current',
            field=models.BooleanField(
                default=True,
                help_text='Whether this is the current/latest facts record'
            ),
        ),
        # Add collected_at timestamp field
        migrations.AddField(
            model_name='devicefacts',
            name='collected_at',
            field=models.DateTimeField(
                auto_now_add=True,
                help_text='When this specific collection occurred'
            ),
            preserve_default=False,
        ),
        # Add index for current flag queries
        migrations.AddIndex(
            model_name='devicefacts',
            index=models.Index(
                fields=['device', 'is_current'],
                name='netops_current_idx'
            ),
        ),
        # Add index for history queries
        migrations.AddIndex(
            model_name='devicefacts',
            index=models.Index(
                fields=['device', 'collected_at'],
                name='netops_history_idx'
            ),
        ),
        # Update ordering to most recent first
        migrations.AlterModelOptions(
            name='devicefacts',
            options={
                'ordering': ['-collected_at'],
                'verbose_name': 'Device Facts',
                'verbose_name_plural': 'Device Facts'
            },
        ),
    ]
