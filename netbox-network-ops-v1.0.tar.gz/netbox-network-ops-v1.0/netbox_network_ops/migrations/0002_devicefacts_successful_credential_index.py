from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('netbox_network_ops', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='devicefacts',
            name='successful_credential_index',
            field=models.IntegerField(
                null=True,
                blank=True,
                help_text='Index (1-3) of credential set that last succeeded'
            ),
        ),
    ]
