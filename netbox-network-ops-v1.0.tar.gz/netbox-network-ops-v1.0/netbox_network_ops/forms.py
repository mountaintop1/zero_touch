from django import forms
from dcim.models import Device, Region


class DeviceChoiceField(forms.ModelChoiceField):
    """ModelChoiceField with custom label format for device display."""

    def label_from_instance(self, obj):
        """Format: Name | IP | Platform"""
        # Handle None primary_ip4
        if obj.primary_ip4:
            ip = str(obj.primary_ip4.address.ip)
        else:
            ip = "No IP"

        # Handle None platform
        if obj.platform:
            platform = obj.platform.name
        else:
            platform = "No platform"

        return f"{obj.name} | {ip} | {platform}"


class DeviceSelectionForm(forms.Form):
    """Form for selecting a device to view/collect facts."""

    region = forms.ModelChoiceField(
        queryset=Region.objects.all(),
        required=False,
        empty_label="All Regions",
        label="Filter by Region",
        help_text="Select region to filter devices (includes child regions)"
    )

    device = DeviceChoiceField(
        queryset=Device.objects.none(),
        required=True,
        empty_label="Select a device",
        label="Device",
        help_text="Choose device to view facts"
    )

    def __init__(self, *args, **kwargs):
        """Initialize form with filtered device queryset."""
        region_id = kwargs.pop('region_id', None)
        super().__init__(*args, **kwargs)

        # Build base queryset: devices with primary_ip4
        devices = Device.objects.filter(
            primary_ip4__isnull=False
        ).select_related(
            'primary_ip4',
            'platform',
            'site',
            'site__region'
        )

        # Apply region filter if provided
        if region_id:
            try:
                region = Region.objects.get(pk=region_id)
                # Include descendants for hierarchical filtering
                descendant_regions = region.get_descendants(include_self=True)
                devices = devices.filter(site__region__in=descendant_regions)
            except Region.DoesNotExist:
                pass

        # Sort by site then device name
        devices = devices.order_by('site__name', 'name')

        self.fields['device'].queryset = devices

        # Disable device field if no devices available
        if not devices.exists():
            self.fields['device'].disabled = True
            self.fields['device'].help_text = "No devices available in selected region"
