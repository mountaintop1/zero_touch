"""
Logging filter to sanitize credentials from log messages.

Prevents passwords, tokens, and other sensitive data from appearing in logs
by applying regex-based sanitization to log records before output.
"""

import logging
import re


class CredentialSanitizerFilter(logging.Filter):
    """
    Logging filter that sanitizes sensitive information from log messages.

    Replaces passwords, tokens, and other credentials with masked values to
    prevent credential exposure in log files.
    """

    # Keys that indicate sensitive values
    SENSITIVE_KEYS = ('password', 'passwd', 'pwd', 'secret', 'token', 'credential')

    # Regex patterns for sanitizing strings
    # Each tuple is (pattern, replacement)
    PATTERNS = [
        # Match password in key-value format: password=value, password: value, etc.
        (r'(password|passwd|pwd)\s*[=:]\s*["\']?([^"\' \n,}]+)', r"\1='******'"),
        # Match username patterns: username=value, user: value, etc.
        (r'(username|user)\s*[=:]\s*["\']?([^"\' \n,}]+)', r"\1='[REDACTED]'"),
    ]

    def filter(self, record):
        """
        Sanitize the log record before output.

        Args:
            record: LogRecord instance to sanitize

        Returns:
            bool: Always True (allow record through, just sanitized)
        """
        # Sanitize the message string
        if isinstance(record.msg, str):
            record.msg = self._sanitize_string(record.msg)

        # Sanitize arguments if present
        if record.args:
            if isinstance(record.args, dict):
                record.args = self._sanitize_dict(record.args)
            elif isinstance(record.args, tuple):
                record.args = tuple(self._sanitize_value(arg) for arg in record.args)

        return True

    def _sanitize_string(self, msg):
        """
        Apply regex patterns to sanitize a string.

        Args:
            msg: String to sanitize (or value convertible to string)

        Returns:
            str: Sanitized string
        """
        # Convert to string if not already
        if not isinstance(msg, str):
            msg = str(msg)

        # Apply all patterns with case-insensitive matching
        for pattern, replacement in self.PATTERNS:
            msg = re.sub(pattern, replacement, msg, flags=re.IGNORECASE)

        return msg

    def _sanitize_dict(self, data):
        """
        Sanitize a dictionary by masking sensitive keys.

        Args:
            data: Dictionary to sanitize

        Returns:
            dict: Sanitized dictionary (new instance)
        """
        sanitized = {}
        for key, value in data.items():
            # Mask value if key is sensitive
            if key.lower() in self.SENSITIVE_KEYS:
                sanitized[key] = '******'
            else:
                # Recursively sanitize the value
                sanitized[key] = self._sanitize_value(value)
        return sanitized

    def _sanitize_value(self, value):
        """
        Sanitize a value of any type.

        Args:
            value: Value to sanitize

        Returns:
            Sanitized value (type matches input)
        """
        if isinstance(value, dict):
            return self._sanitize_dict(value)
        elif isinstance(value, str):
            return self._sanitize_string(value)
        else:
            # Non-string, non-dict values returned as-is
            return value


def configure_logging():
    """
    Configure credential sanitization for all logging output.

    Adds CredentialSanitizerFilter to the root logger and the plugin-specific
    logger to prevent credential exposure in any log messages.

    Must be called during plugin initialization (PluginConfig.ready()) BEFORE
    any credential loading operations to ensure early log messages are sanitized.
    """
    sanitizer = CredentialSanitizerFilter()

    # Add filter to root logger handlers
    root_logger = logging.getLogger()
    for handler in root_logger.handlers:
        handler.addFilter(sanitizer)

    # Also add to plugin-specific logger
    plugin_logger = logging.getLogger('netbox_network_ops')
    for handler in plugin_logger.handlers:
        handler.addFilter(sanitizer)
