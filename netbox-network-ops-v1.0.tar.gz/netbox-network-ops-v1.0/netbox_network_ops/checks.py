"""
Django system checks for NetBox Network Operations plugin.

Validates credential environment variables at startup, producing errors for
missing primary credentials and warnings for incomplete backup credential sets.
"""

import os
from django.core.checks import Error, Warning, register


@register()
def check_credential_environment(app_configs, **kwargs):
    """
    Validate credential environment variables.

    Checks that required primary credentials (set 1) are present and that
    optional backup credentials (sets 2 and 3) are complete if partially
    configured.

    Returns:
        list: List of Error and Warning objects for any validation issues.

    Errors:
        E001: NETOPS_USERNAME_1 not set
        E002: NETOPS_PASSWORD_1 not set

    Warnings:
        W001: NETOPS_USERNAME_2 set but NETOPS_PASSWORD_2 missing
        W002: NETOPS_PASSWORD_2 set but NETOPS_USERNAME_2 missing
        W003: NETOPS_USERNAME_3 set but NETOPS_PASSWORD_3 missing
        W004: NETOPS_PASSWORD_3 set but NETOPS_USERNAME_3 missing
    """
    errors = []

    # Check required primary credentials (set 1)
    if not os.environ.get('NETOPS_USERNAME_1'):
        errors.append(
            Error(
                'NETOPS_USERNAME_1 environment variable is not set',
                hint='Set NETOPS_USERNAME_1 in your environment or .env file',
                id='netbox_network_ops.E001'
            )
        )

    if not os.environ.get('NETOPS_PASSWORD_1'):
        errors.append(
            Error(
                'NETOPS_PASSWORD_1 environment variable is not set',
                hint='Set NETOPS_PASSWORD_1 in your environment or .env file',
                id='netbox_network_ops.E002'
            )
        )

    # Check optional backup credential set 2 for completeness
    username_2 = os.environ.get('NETOPS_USERNAME_2')
    password_2 = os.environ.get('NETOPS_PASSWORD_2')

    if username_2 and not password_2:
        errors.append(
            Warning(
                'NETOPS_USERNAME_2 is set but NETOPS_PASSWORD_2 is missing',
                hint='Either set both NETOPS_USERNAME_2 and NETOPS_PASSWORD_2, or remove NETOPS_USERNAME_2. '
                     'Incomplete credential set 2 will be ignored.',
                id='netbox_network_ops.W001'
            )
        )

    if password_2 and not username_2:
        errors.append(
            Warning(
                'NETOPS_PASSWORD_2 is set but NETOPS_USERNAME_2 is missing',
                hint='Either set both NETOPS_USERNAME_2 and NETOPS_PASSWORD_2, or remove NETOPS_PASSWORD_2. '
                     'Incomplete credential set 2 will be ignored.',
                id='netbox_network_ops.W002'
            )
        )

    # Check optional backup credential set 3 for completeness
    username_3 = os.environ.get('NETOPS_USERNAME_3')
    password_3 = os.environ.get('NETOPS_PASSWORD_3')

    if username_3 and not password_3:
        errors.append(
            Warning(
                'NETOPS_USERNAME_3 is set but NETOPS_PASSWORD_3 is missing',
                hint='Either set both NETOPS_USERNAME_3 and NETOPS_PASSWORD_3, or remove NETOPS_USERNAME_3. '
                     'Incomplete credential set 3 will be ignored.',
                id='netbox_network_ops.W003'
            )
        )

    if password_3 and not username_3:
        errors.append(
            Warning(
                'NETOPS_PASSWORD_3 is set but NETOPS_USERNAME_3 is missing',
                hint='Either set both NETOPS_USERNAME_3 and NETOPS_PASSWORD_3, or remove NETOPS_PASSWORD_3. '
                     'Incomplete credential set 3 will be ignored.',
                id='netbox_network_ops.W004'
            )
        )

    return errors
