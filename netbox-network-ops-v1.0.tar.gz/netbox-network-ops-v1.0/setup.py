from setuptools import find_packages, setup

setup(
    name="netbox-network-ops",
    version="1.0.0",
    description="NetBox plugin to collect and display live device facts from network devices via SSH",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author="Network Operations Team",
    author_email="netops@example.com",
    url="https://github.com/your-org/netbox-network-ops",
    license="Apache 2.0",
    install_requires=[
        "napalm>=4.0.0",
    ],
    packages=find_packages(exclude=['tests', 'tests.*']),
    include_package_data=True,
    zip_safe=False,
    keywords="netbox plugin network automation napalm ssh",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Framework :: Django",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: Apache Software License",
        "Natural Language :: English",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: System :: Networking",
    ],
    python_requires='>=3.10',
)
