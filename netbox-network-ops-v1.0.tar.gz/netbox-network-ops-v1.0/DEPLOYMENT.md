# NetBox Network Operations Plugin - Deployment Guide

## Overview

This guide covers production deployment considerations for the NetBox Network Operations plugin, including SSH connectivity configuration, background job infrastructure, and credential management.

## SSH Connectivity

### Legacy SSH Algorithm Support

The plugin enables legacy SSH algorithms by default for maximum compatibility with aging network infrastructure (Cisco IOS 12.x, older NXOS, etc.).

**How it works:**
- The plugin disables modern SSH algorithms in Paramiko, forcing negotiation of legacy algorithms
- This happens automatically - no configuration required
- Works with: diffie-hellman-group1-sha1, diffie-hellman-group14-sha1, ssh-rsa, ssh-dss

**Disabled modern algorithms:**
- Key Exchange (KEX): curve25519-sha256, diffie-hellman-group-exchange-sha256, diffie-hellman-group16-sha512, diffie-hellman-group18-sha512
- Host Keys: rsa-sha2-512, rsa-sha2-256

**Why this matters:**
Many production network devices, especially in enterprise environments with long hardware refresh cycles, only support older SSH algorithms. Without the `disabled_algorithms` configuration, Paramiko's default behavior is to prefer modern algorithms, causing connections to fail with "Unable to negotiate key exchange algorithm" or similar errors.

### Security Considerations

Enabling legacy SSH algorithms involves a security trade-off:

- **Benefit:** Connects to aging infrastructure that only supports weak algorithms
- **Risk:** Legacy algorithms (diffie-hellman-group1-sha1, ssh-dss) are considered cryptographically weak

**Mitigations:**
- Network segmentation: Restrict management network access to trusted administrators
- Device authentication: Use strong, unique credentials per environment
- Monitoring: Review connection logs for unexpected algorithm usage
- Credential rotation: Regularly rotate device credentials

**For security-conscious environments:**
If your infrastructure exclusively uses modern devices that support strong cryptography, you can modify the `disabled_algorithms` configuration in `netbox_network_ops/connection.py` to remove specific algorithms from the disabled list. This will allow Paramiko to negotiate modern algorithms while still supporting legacy ones where needed.

### System-Level SSH Configuration (Optional)

For manual SSH debugging outside Python (e.g., `ssh user@device` from command line), you may need system-level SSH configuration.

**Note:** Paramiko (used by the plugin) does NOT read system SSH config files. The system config is only needed for manual SSH sessions.

**Linux (/etc/ssh/ssh_config or ~/.ssh/config):**

```
# Enable legacy algorithms for network devices
Host *
    KexAlgorithms +diffie-hellman-group1-sha1,diffie-hellman-group14-sha1
    HostKeyAlgorithms +ssh-rsa,ssh-dss
    PubkeyAcceptedAlgorithms +ssh-rsa
```

**macOS (same location as Linux):**

System-level SSH config may be restricted by macOS security policies. If manual SSH debugging is required, use per-host configuration in `~/.ssh/config` instead of system-wide `/etc/ssh/ssh_config`.

### Troubleshooting SSH Connections

**"SSH algorithm negotiation failed" error:**
1. Plugin already enables legacy algorithms - check device supports at least one
2. Some very old devices may need additional algorithms enabled in connection.py
3. Check NetBox logs for algorithm details: `docker-compose logs netbox | grep "SSH session"`
4. Verify device SSH server is running: `telnet <device-ip> 22` (should see SSH banner)

**Connection timeout:**
1. Verify device IP is correct in NetBox (Device → Primary IPv4)
2. Check device is reachable: `ping <device-ip>`
3. Verify SSH port is open: `nc -zv <device-ip> 22` or `telnet <device-ip> 22`
4. Check firewall rules between NetBox and device management network
5. Review timeout configuration: default is 30 seconds (connection.py)

**Authentication failed:**
1. Verify credentials in environment variables (NETOPS_USERNAME_*, NETOPS_PASSWORD_*)
2. Check device accepts those credentials via manual SSH: `ssh username@device-ip`
3. Review credential fallback: plugin tries multiple credential sets automatically
4. Check device AAA configuration: some devices require specific privilege levels
5. Verify credentials are loaded: Check NetBox logs on startup for credential count

**Connection succeeds but no facts collected:**
1. Check platform mapping: Device platform must map to NAPALM driver (see platforms.py)
2. Verify NAPALM supports the device OS version
3. Check NetBox logs for NAPALM-specific errors
4. Test manually with NAPALM CLI to isolate driver issues

## RQ Worker Configuration

The plugin uses NetBox's built-in RQ worker for background jobs (facts collection). Ensure the worker container is running and processing jobs.

**Check worker status:**
```bash
docker-compose ps worker
```

**View worker logs:**
```bash
docker-compose logs -f worker
```

**Worker restart (after code changes):**
```bash
docker-compose restart worker
```

**Job queue health:**
NetBox's RQ implementation does not support automatic retry. If a job fails, users must manually retry from the UI. Monitor worker logs for patterns of recurring failures that may indicate infrastructure issues.

**Performance tuning:**
For large-scale deployments with hundreds of devices, consider increasing worker concurrency. This requires modifying the NetBox Docker configuration to spawn additional worker processes.

## Environment Variables

Required credentials for device access:

```bash
# Primary credentials
NETOPS_USERNAME_1=admin
NETOPS_PASSWORD_1=<password>

# Optional backup credentials (fallback on auth failure)
NETOPS_USERNAME_2=backup
NETOPS_PASSWORD_2=<backup-password>
```

**Configuration location:**
- Development: `netbox_network_ops_dev/env/netbox.env`
- Production: Your NetBox environment file (varies by deployment method)

**Credential fallback behavior:**
The plugin tries each credential set in order until one succeeds. Successful credentials are remembered per-device for faster future connections.

**After changing credentials:**
```bash
docker-compose restart netbox worker
```

**Security best practices:**
- Use dedicated read-only accounts where possible
- Rotate credentials regularly
- Never commit credentials to version control
- Use different credentials per environment (dev/staging/production)

## Deployment Checklist

Before deploying to production:

- [ ] Environment variables configured with valid credentials
- [ ] Worker container running and processing jobs
- [ ] Network connectivity verified between NetBox and device management network
- [ ] Platform mappings verified for your device types (see platforms.py)
- [ ] Test facts collection on representative device sample
- [ ] Monitor logs for authentication or connection errors
- [ ] Review security considerations for legacy SSH algorithm usage
- [ ] Document any custom platform mappings or credential requirements

## Production Monitoring

**Key metrics to monitor:**
- Facts collection success rate per platform
- Connection timeout frequency
- Authentication failure patterns
- Worker queue depth and processing time

**Log locations:**
- NetBox container: `docker-compose logs netbox`
- Worker container: `docker-compose logs worker`
- Facts collection jobs: NetBox Admin → Background Tasks

**Common production issues:**
- Credential rotation breaking existing jobs: Update environment variables and restart
- Network changes blocking SSH access: Verify firewall rules
- Platform updates changing SSH algorithms: May require connection.py adjustments
