# NetBox Network Operations - Deployment Notes

## DEBUG Mode Explained

### Why DEBUG=true in This Package?

This Docker environment is configured with `DEBUG=true` in `env/netbox.env`. This is **intentional and necessary** for the following reason:

**Django's Static File Behavior:**
- When `DEBUG=false`, Django refuses to serve static files (CSS, JavaScript, images)
- This is a security feature - Django expects a production web server to handle static files
- Without static files, NetBox's interface breaks (shows "Static Media Failure")

**For Docker Standalone:**
- No nginx or Apache is configured
- Django must serve its own static files
- Therefore, `DEBUG=true` is required

### Is DEBUG=true Safe?

**It depends on your deployment:**

| Deployment Type | DEBUG=true Safe? | Recommendation |
|----------------|------------------|----------------|
| Internal network only | ✓ Yes | Use as-is |
| Development/Testing | ✓ Yes | Use as-is |
| VPN-only access | ✓ Yes | Use as-is |
| Internet-facing | ✗ No | Set up nginx (see below) |
| Production with sensitive data | ✗ No | Set up nginx |

**Why DEBUG=true can be risky:**
- Shows detailed error pages with stack traces
- Exposes internal code paths
- May reveal configuration details
- Not recommended for public-facing sites

**Why DEBUG=true is often acceptable:**
- Many internal tools run with DEBUG=true
- NetBox has authentication required by default
- Risk is low if network access is restricted

### Production Deployment Options

#### Option 1: Keep DEBUG=true (Recommended for Internal Use)

**Use when:**
- Deploying to internal network
- Access restricted by firewall/VPN
- Not handling highly sensitive data

**Advantages:**
- Simple configuration
- Works immediately
- No additional containers

**Security measures:**
- Keep `LOGIN_REQUIRED=true`
- Use strong passwords
- Restrict network access
- Keep NetBox updated

#### Option 2: Add Nginx Reverse Proxy (Internet-Facing Production)

**Use when:**
- Deploying to internet
- Handling sensitive network data
- Require SSL/TLS
- Need caching and performance

**Configuration:**
See "Production with Nginx" section in README-DOCKER.md for complete setup.

**Advantages:**
- DEBUG=false (production-safe)
- SSL termination
- Static file caching
- Load balancing support
- Industry standard approach

## Quick Decision Guide

**Ask yourself:**

1. **Will this be accessible from the internet?**
   - Yes → Use nginx (Option 2)
   - No → DEBUG=true is fine (Option 1)

2. **Is this for a large organization with security requirements?**
   - Yes → Use nginx (Option 2)
   - No → DEBUG=true is acceptable (Option 1)

3. **Do you need SSL/HTTPS?**
   - Yes → Use nginx (Option 2)
   - No → DEBUG=true is sufficient (Option 1)

## Recommended Deployment by Environment

### Development/Testing
```bash
DEBUG=true          # As configured
LOGIN_REQUIRED=false  # Optional for easier testing
ALLOWED_HOSTS=*     # As configured
```

### Internal Production (Corporate Network)
```bash
DEBUG=true          # Keep for simplicity
LOGIN_REQUIRED=true # Enforce authentication
ALLOWED_HOSTS=netbox.internal.company.com
```

### Internet-Facing Production
```bash
DEBUG=false         # After nginx setup
LOGIN_REQUIRED=true
ALLOWED_HOSTS=netbox.yourdomain.com
# + nginx reverse proxy with SSL
```

## Summary

This package is configured for **standalone Docker deployment with DEBUG=true**. This is:
- ✓ Appropriate for internal use
- ✓ Simple and reliable
- ✓ No additional configuration needed
- ✗ Not recommended for internet-facing deployment without nginx

For internet-facing production, follow the nginx setup guide in README-DOCKER.md to enable DEBUG=false safely.
