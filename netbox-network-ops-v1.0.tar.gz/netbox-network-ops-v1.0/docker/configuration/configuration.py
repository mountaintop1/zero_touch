"""
NetBox Configuration for NetBox Network Operations Plugin

This configuration file is designed for production use with the plugin.
Customize as needed for your environment.
"""

import os

# Allowed hosts - set to your NetBox domain(s) in production
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "*").split(" ")

# Database configuration
DATABASE = {
    "NAME": os.environ.get("DB_NAME", "netbox"),
    "USER": os.environ.get("DB_USER", "netbox"),
    "PASSWORD": os.environ.get("DB_PASSWORD", "netbox"),
    "HOST": os.environ.get("DB_HOST", "postgres"),
    "PORT": int(os.environ.get("DB_PORT", "5432")),
    "CONN_MAX_AGE": int(os.environ.get("DB_CONN_MAX_AGE", "300")),
}

# Secret key - MUST be changed in production
SECRET_KEY = os.environ.get(
    "SECRET_KEY",
    "r(m)9nLGnz$(_q3N4z1k(EFsMCjjjzx08x9VhNVcfd%6RF#r!6DE@+V5Zk2X"
)

# API token pepper - enables v2 API tokens
# NOTE: Do not override in env file - use this default or generate a new one here
API_TOKEN_PEPPERS = {
    0: "netboxapitokenpeppersecret12345678901234567890123456",
}

# Redis configuration
REDIS = {
    "tasks": {
        "HOST": os.environ.get("REDIS_HOST", "redis"),
        "PORT": int(os.environ.get("REDIS_PORT", "6379")),
        "PASSWORD": os.environ.get("REDIS_PASSWORD", "redis"),
        "DATABASE": int(os.environ.get("REDIS_TASKS_DB", "0")),
        "SSL": os.environ.get("REDIS_SSL", "false").lower() == "true",
    },
    "caching": {
        "HOST": os.environ.get("REDIS_HOST", "redis"),
        "PORT": int(os.environ.get("REDIS_PORT", "6379")),
        "PASSWORD": os.environ.get("REDIS_PASSWORD", "redis"),
        "DATABASE": int(os.environ.get("REDIS_CACHE_DB", "1")),
        "SSL": os.environ.get("REDIS_SSL", "false").lower() == "true",
    },
}

# Debug mode - Required for Docker standalone deployment to serve static files
# For production with nginx/Apache reverse proxy, set to false
DEBUG = os.environ.get("DEBUG", "true").lower() == "true"

# Developer mode - Suppresses debug warning banner in UI
DEVELOPER = os.environ.get("DEVELOPER", "true").lower() == "true"

# Internal IPs for debug toolbar
INTERNAL_IPS = ("127.0.0.1", "::1")

# Enable plugins
PLUGINS = [
    'netbox_network_ops',
]

# Plugin configuration
PLUGINS_CONFIG = {
    'netbox_network_ops': {
        # Plugin-specific configuration can go here if needed
    }
}

# Scripts root directory
SCRIPTS_ROOT = os.environ.get("SCRIPTS_ROOT", "/opt/netbox/scripts")

# Login required
LOGIN_REQUIRED = os.environ.get("LOGIN_REQUIRED", "true").lower() == "true"

# Enable GraphQL
GRAPHQL_ENABLED = os.environ.get("GRAPHQL_ENABLED", "true").lower() == "true"

# CORS settings - adjust for production
CORS_ORIGIN_ALLOW_ALL = os.environ.get("CORS_ORIGIN_ALLOW_ALL", "false").lower() == "true"

# Maximum page size for API
MAX_PAGE_SIZE = int(os.environ.get("MAX_PAGE_SIZE", "1000"))

# Media root
MEDIA_ROOT = os.environ.get("MEDIA_ROOT", "/opt/netbox/netbox/media")

# Enforce global unique
ENFORCE_GLOBAL_UNIQUE = os.environ.get("ENFORCE_GLOBAL_UNIQUE", "true").lower() == "true"

# Webhooks enabled
WEBHOOKS_ENABLED = os.environ.get("WEBHOOKS_ENABLED", "true").lower() == "true"

