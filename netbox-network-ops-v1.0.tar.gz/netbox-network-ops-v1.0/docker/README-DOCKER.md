# NetBox Network Operations Plugin - Docker Deployment

Complete Docker Compose environment for running NetBox with the Network Operations plugin.

**IMPORTANT:** This environment uses `DEBUG=true` to serve static files. See `DEPLOYMENT-NOTES.md` for security considerations and production nginx setup.

## Quick Start

```bash
# 1. Configure credentials
cd docker
cp env/netbox.env env/netbox.env.local  # Optional: keep template clean
nano env/netbox.env  # Edit device credentials

# 2. Start services
docker-compose up -d

# 3. Wait for initialization (~60 seconds)
docker-compose logs -f netbox

# 4. Access NetBox
# Open browser: http://localhost:9000
# Login: admin / admin (default)
# Navigate to: Plugins → Network Operations
```

## Architecture

This Docker environment includes:

- **NetBox** (port 8000) - Main web application
- **Worker** - Background job processor (RQ)
- **PostgreSQL** (port 5432) - Database
- **Redis** (port 6379) - Cache and task queue

The plugin is mounted from `../netbox_network_ops/` (read-only) and installed automatically on startup.

## Volume Mounts

```yaml
# Plugin source code (read-only)
../netbox_network_ops:/plugins/netbox-network-ops:ro

# NetBox configuration (read-only)
./configuration/configuration.py:/opt/netbox/netbox/netbox/configuration.py:ro
```

**Key Points:**
- Plugin directory is mounted as **read-only** (`:ro`)
- No confusion about which directory - it's `../netbox_network_ops/`
- Configuration is also read-only for safety
- Changes to plugin code require container restart

## Configuration

### Device Credentials

Edit `env/netbox.env`:

```bash
# Primary credentials (tried first)
NETOPS_USERNAME_1=your_device_username
NETOPS_PASSWORD_1=your_device_password

# Backup credentials (tried if primary fails)
NETOPS_USERNAME_2=backup_username
NETOPS_PASSWORD_2=backup_password
```

### NetBox Settings

Edit `configuration/configuration.py` for advanced configuration:

```python
# Example: Restrict allowed hosts
ALLOWED_HOSTS = ['netbox.yourdomain.com']

# Example: Enable strict login
LOGIN_REQUIRED = True
```

### Security Settings

**IMPORTANT:** Before production deployment:

1. **Change SECRET_KEY:**
   ```bash
   python3 -c 'from secrets import token_urlsafe; print(token_urlsafe(50))'
   ```
   Update in `env/netbox.env`

2. **Change all passwords:**
   - `SUPERUSER_PASSWORD` (NetBox admin)
   - `DB_PASSWORD` (PostgreSQL)
   - `REDIS_PASSWORD` (Redis)
   - `NETOPS_PASSWORD_1` and `NETOPS_PASSWORD_2` (devices)

## Understanding DEBUG Mode

This Docker environment uses `DEBUG=true` by default. Here's why:

**Why DEBUG=true?**
- Django doesn't serve static files (CSS/JS) when `DEBUG=false` (security feature)
- Without static files, the web interface shows "Static Media Failure" errors
- For standalone Docker deployment, `DEBUG=true` is the simplest solution

**Is this secure for production?**
- **For internal tools/testing:** Yes, this is acceptable
- **For internet-facing production:** No, use nginx (see below)

**When to use DEBUG=false:**
- Only after setting up nginx/Apache reverse proxy to serve static files
- See "Production with Nginx" section below for configuration

## Common Commands

### Start/Stop Services

```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# Restart specific service
docker-compose restart netbox
docker-compose restart worker

# View logs
docker-compose logs -f netbox
docker-compose logs -f worker
```

### Database Operations

```bash
# Run migrations
docker-compose exec netbox python manage.py migrate

# Create superuser
docker-compose exec netbox python manage.py createsuperuser

# Django shell
docker-compose exec netbox python manage.py shell

# Database backup
docker-compose exec postgres pg_dump -U netbox netbox > backup.sql

# Database restore
docker-compose exec -T postgres psql -U netbox netbox < backup.sql
```

### Plugin Management

```bash
# Check plugin is installed
docker-compose exec netbox pip list | grep netbox-network-ops

# View plugin logs
docker-compose exec netbox python manage.py check netbox_network_ops

# Reinstall plugin (if code changed)
docker-compose restart netbox worker
```

### Troubleshooting

```bash
# View all logs
docker-compose logs -f

# Check service status
docker-compose ps

# Inspect specific service
docker-compose exec netbox bash

# Check plugin credentials
docker-compose exec netbox env | grep NETOPS

# Test device connectivity
docker-compose exec netbox bash
ssh admin@device-ip  # Test from inside container
```

## File Structure

```
docker/
├── docker-compose.yml         # Service definitions
├── Dockerfile                 # NetBox image with plugin
├── entrypoint.sh             # Startup script
├── configuration/
│   └── configuration.py      # NetBox config
├── env/
│   ├── netbox.env           # NetBox + plugin credentials
│   ├── postgres.env         # Database config
│   └── redis.env            # Redis config
└── README-DOCKER.md         # This file

../netbox_network_ops/        # Plugin source (mounted)
```

## Port Mappings

| Service | Internal Port | External Port | Description |
|---------|--------------|---------------|-------------|
| NetBox | 8000 | 9000 | Web interface |
| PostgreSQL | 5432 | 5434 | Database |
| Redis | 6379 | 6381 | Cache/Queue |

External ports configured to avoid conflicts with default installations.

## Data Persistence

Docker volumes store persistent data:

- `pgdata` - PostgreSQL database
- `redis-data` - Redis persistence

Data survives container restarts and `docker-compose down`.

To completely remove data:
```bash
docker-compose down -v  # WARNING: Deletes all data!
```

## Production Deployment

### Pre-Production Checklist

- [ ] Changed all default passwords
- [ ] Generated new SECRET_KEY
- [ ] Set ALLOWED_HOSTS to actual domain
- [ ] Configured device credentials
- [ ] Tested plugin on sample device
- [ ] Set up database backups
- [ ] Configured log retention
- [ ] (Optional) Set up nginx reverse proxy if deploying to internet (see "Production with Nginx" section)

### Production Recommendations

1. **Use Docker secrets** instead of env files:
   ```yaml
   secrets:
     - netbox_secret_key
     - db_password
   ```

2. **Use external database** for production scale

3. **Set up reverse proxy** (nginx/traefik) with SSL

4. **Configure resource limits**:
   ```yaml
   deploy:
     resources:
       limits:
         cpus: '2'
         memory: 4G
   ```

5. **Enable container health checks and monitoring**

6. **Set up automated backups**

### Production with Nginx (DEBUG=false)

For internet-facing production, add nginx to serve static files and enable SSL:

**1. Add nginx service to docker-compose.yml:**
```yaml
nginx:
  image: nginx:alpine
  ports:
    - "443:443"
    - "80:80"
  volumes:
    - ./nginx.conf:/etc/nginx/nginx.conf:ro
    - ./ssl:/etc/nginx/ssl:ro
    - static-files:/usr/share/nginx/html/static:ro
  depends_on:
    - netbox

# Add shared volume for static files
volumes:
  static-files:
```

**2. Create nginx.conf:**
```nginx
upstream netbox {
    server netbox:8000;
}

server {
    listen 80;
    client_max_body_size 25m;

    location /static/ {
        alias /usr/share/nginx/html/static/;
    }

    location / {
        proxy_pass http://netbox;
        proxy_set_header X-Forwarded-Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**3. Update env/netbox.env:**
```bash
DEBUG=false  # Now safe with nginx handling static files
```

**4. Collect static files to shared volume:**
```bash
docker-compose exec netbox python manage.py collectstatic --no-input
docker cp netbox:/opt/netbox/netbox/static/. ./static/
```

## Upgrading

### Upgrade NetBox Version

1. Update `NETBOX_VERSION` in `docker-compose.yml`:
   ```yaml
   args:
     NETBOX_VERSION: v4.2.0  # New version
   ```

2. Rebuild and restart:
   ```bash
   docker-compose build --no-cache
   docker-compose down
   docker-compose up -d
   ```

3. Check migrations:
   ```bash
   docker-compose exec netbox python manage.py migrate
   ```

### Upgrade Plugin

1. Update plugin source in `../netbox_network_ops/`
2. Restart services:
   ```bash
   docker-compose restart netbox worker
   ```

## Monitoring

### Health Checks

NetBox includes a health check:
```bash
curl http://localhost:8000/login/
```

Check in docker-compose:
```bash
docker-compose ps
# HEALTHY status indicates service is running
```

### Logs

```bash
# Real-time logs
docker-compose logs -f

# Save logs to file
docker-compose logs > netbox-logs.txt

# Filter by service
docker-compose logs netbox | grep ERROR
```

### Resource Usage

```bash
# Container stats
docker stats

# Disk usage
docker system df
```

## Backup and Restore

### Full Backup

```bash
# Database
docker-compose exec postgres pg_dump -U netbox netbox > db-backup-$(date +%Y%m%d).sql

# Media files (if any)
docker-compose exec netbox tar -czf /tmp/media.tar.gz /opt/netbox/netbox/media
docker cp netbox:/tmp/media.tar.gz media-backup-$(date +%Y%m%d).tar.gz

# Configuration
tar -czf config-backup-$(date +%Y%m%d).tar.gz env/ configuration/
```

### Restore from Backup

```bash
# Restore database
docker-compose exec -T postgres psql -U netbox netbox < db-backup-20260129.sql

# Restore media
docker cp media-backup-20260129.tar.gz netbox:/tmp/
docker-compose exec netbox tar -xzf /tmp/media-backup-20260129.tar.gz -C /

# Restart services
docker-compose restart
```

## Performance Tuning

### Database

Edit `env/postgres.env`:
```bash
POSTGRES_MAX_CONNECTIONS=200
POSTGRES_SHARED_BUFFERS=512MB
POSTGRES_EFFECTIVE_CACHE_SIZE=2GB
```

### Redis

Edit `env/redis.env`:
```bash
REDIS_MAXMEMORY=1gb
REDIS_MAXMEMORY_POLICY=allkeys-lru
```

### Worker Count

Scale workers:
```bash
docker-compose up -d --scale worker=3
```

## Troubleshooting

### Plugin Not Appearing

1. Check installation:
   ```bash
   docker-compose exec netbox pip list | grep netbox-network-ops
   ```

2. Check configuration:
   ```bash
   docker-compose exec netbox python manage.py shell
   >>> from django.conf import settings
   >>> print(settings.PLUGINS)
   ```

3. Check logs:
   ```bash
   docker-compose logs netbox | grep -i error
   ```

### Credentials Not Loading

1. Verify environment:
   ```bash
   docker-compose exec netbox env | grep NETOPS
   ```

2. Check Django system checks:
   ```bash
   docker-compose exec netbox python manage.py check netbox_network_ops
   ```

### Connection Issues

1. Test from container:
   ```bash
   docker-compose exec netbox bash
   ssh admin@device-ip
   ping device-ip
   ```

2. Check network connectivity

3. Verify credentials are correct

### Worker Not Processing Jobs

1. Check worker is running:
   ```bash
   docker-compose ps worker
   ```

2. Check worker logs:
   ```bash
   docker-compose logs -f worker
   ```

3. Restart worker:
   ```bash
   docker-compose restart worker
   ```

## Support

- **Documentation:** See `../DOCUMENTATION.md`
- **Quick Start:** See `../QUICKSTART.md`
- **Deployment:** See `../DEPLOYMENT.md`

## Version Info

- **Plugin Version:** 1.0.0
- **NetBox Version:** 4.1.6 (configurable)
- **Docker Compose Version:** 3.8
- **Python:** 3.10+ (from NetBox base image)

---

**Ready to Deploy!** 🚀

This Docker environment is production-ready with proper security configurations.
Follow the production checklist before deploying to production servers.
