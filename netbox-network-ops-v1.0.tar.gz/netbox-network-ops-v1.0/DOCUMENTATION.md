# NetBox Network Operations Plugin - Documentation

Deep-dive documentation covering architecture, design decisions, advanced configuration, and troubleshooting.

For installation and basic usage, see [SETUP_GUIDE.md](SETUP_GUIDE.md) and [DEPLOYMENT.md](DEPLOYMENT.md).

## Table of Contents

- [Architecture](#architecture)
- [Design Decisions](#design-decisions)
- [Advanced Configuration](#advanced-configuration)
- [Troubleshooting](#troubleshooting)
- [API Reference](#api-reference)
- [FAQ](#faq)

---

## Architecture

### System Overview

```
User Browser
     |
     v
[NetBox Web Server]
     |
     +---> [Plugin Views] ---> [Background Jobs]
                                      |
                                      v
                              [Facts Collection Service]
                                      |
                                      v
                              [Device Connector]
                                      |
                                      v
                              [NAPALM Driver] ---> [Network Device]
```

### Layered Architecture

The plugin follows a clean layered architecture where each layer has a single responsibility:

| Layer | Module | Responsibility |
|-------|--------|----------------|
| **Platform** | `platforms.py` | Map NetBox platform slugs to NAPALM driver names |
| **Credentials** | `credentials.py` | Load and manage credentials from environment variables |
| **Connection** | `connection.py` | Establish SSH connections with fallback/retry logic |
| **Extraction** | `facts_extraction.py` | Normalize platform-specific facts data |
| **Collection** | `facts_collection.py` | Orchestrate connection → retrieval → storage pipeline |
| **Jobs** | `jobs.py` | Background job infrastructure with progress tracking |
| **Views** | `views.py` | User interface for device selection and display |
| **API** | `api/views.py` | REST endpoints for job status polling |

### Data Flow

#### 1. Trigger Collection

- User clicks "Collect Facts" button in web UI
- `CollectFactsView` receives POST request with device ID
- View creates background job via `trigger_facts_collection()`
- Job enqueued in Redis Queue (RQ)
- View returns JSON with `job_id` for AJAX polling
- JavaScript begins polling `/api/jobs/{job_id}/status/` every 5 seconds

#### 2. Job Execution

- RQ worker picks up job from queue
- `FactsCollectionJob.run()` executes
- Job updates progress field at each stage:
  - 0%: Initializing
  - 25%: Connecting to device
  - 50%: Retrieving facts
  - 75%: Saving to database
  - 100%: Completed (or failed)
- Worker calls `collect_facts()` to perform actual work

#### 3. Facts Collection

Connection phase (OUTSIDE transaction to avoid DB locks during slow SSH):
- `DeviceConnector` initialized with NetBox device object
- Platform slug mapped to NAPALM driver name (e.g., `cisco_ios` → `ios`)
- Connector retrieves credential sets from environment variables
- If device has previous facts, last successful credential tried first (optimization)
- SSH connection established with 30-second timeout
- On authentication failure: tries next credential set (credential fallback)
- On timeout: retries once, then aborts (no credential fallback)
- On network error: aborts immediately (no retry, no credential fallback)
- Returns index of successful credential (1-based)

Facts retrieval:
- NAPALM driver's `get_facts()` method called
- Returns dictionary with keys: hostname, fqdn, vendor, model, serial_number, os_version, uptime, interface_list
- Platform-specific quirks handled by `extract_facts()`:
  - JunOS: May return `null` hostname (normalized to empty string)
  - Cisco: Vendor normalized from "Cisco Systems" to "Cisco"

#### 4. Database Storage

Atomic transaction ensures consistency:
- All existing `DeviceFacts` records for device marked `is_current=False`
- New `DeviceFacts` record created with `is_current=True`
- Record includes: collection_status (success/failed), timestamp, facts fields, error message (if failed)
- Successful credential index saved for optimization on next collection
- Transaction committed (all or nothing - prevents partial updates)

#### 5. Display

- User views device facts page or AJAX polling completes
- View queries `DeviceFacts.objects.filter(device=device, is_current=True)`
- Template displays side-by-side comparison:
  - Left column: NetBox data (device.name, device.device_type, etc.)
  - Right column: Live device facts (facts.hostname, facts.model, etc.)
- Mismatches highlighted if values differ
- Empty state shown if no facts collected yet
- Error state shown if collection failed with user-friendly error message
- Staleness indicator shown if facts older than 24 hours

---

## Design Decisions

### Why SSH-Only (No NETCONF)

**Decision:** Use SSH transport exclusively via NAPALM's SSH drivers

**Rationale:**
- Universal support across Cisco IOS/IOS-XE/NXOS and Juniper JunOS
- Simpler implementation for v1 - no XML parsing or YANG models
- NAPALM's SSH drivers are mature, well-tested, and actively maintained
- Most network devices support SSH out-of-the-box
- Aligns with existing operational practices (operators already use SSH)

**Trade-offs:**
- Slower than NETCONF (SSH CLI scraping vs. structured API)
- Less structured data (text parsing vs. XML/JSON)
- More brittle to OS version changes (CLI output changes require driver updates)

**Future consideration:** NETCONF support can be added as enhancement while maintaining SSH fallback

---

### Why Background Jobs

**Decision:** Execute facts collection asynchronously via NetBox's JobRunner (RQ-based)

**Rationale:**
- SSH connections take 5-30+ seconds depending on network latency, device load, and algorithm negotiation
- Blocking web workers during SSH operations causes poor UX (page hangs)
- Enables concurrent collections without blocking other users
- Provides built-in progress tracking, retry logic, and job history
- Integrates with NetBox's existing job infrastructure (familiar to operators)

**Implementation details:**
- Jobs enqueued with `trigger_facts_collection()` helper function
- Progress tracked via `job.data` field (0%, 25%, 50%, 75%, 100%)
- Frontend polls job status endpoint every 5 seconds
- Auto-reload on completion shows fresh data

**Trade-offs:**
- Requires RQ worker process running (additional operational complexity)
- Cannot return facts immediately (must poll for completion)
- Job queue can become backlog under heavy load

---

### Why Credential Memory

**Decision:** Remember which credential last succeeded and try it first on next connection

**Rationale:**
- Reduces connection time on subsequent attempts (no need to try failed credentials first)
- Particularly beneficial in heterogeneous environments with many credential sets
- Simple optimization with minimal code complexity

**Implementation:**
- `DeviceFacts.successful_credential_index` stores last successful credential (1-based)
- `get_prioritized_credentials()` reorders credential list to try successful credential first
- Falls back to trying all credentials if previously successful credential fails

**Example:** Device uses credential set 3
- First connection: tries credentials 1, 2, 3 (succeeds on 3) → saves index 3
- Second connection: tries credentials 3, 1, 2 (succeeds immediately) → saves index 3
- Third connection (credential rotated): tries credentials 3 (fails), 1, 2, 4 (succeeds on 4) → saves index 4

---

### Why Atomic is_current Flag

**Decision:** Use database transaction to ensure exactly one "current" facts record per device

**Rationale:**
- Prevents race conditions if multiple collections triggered simultaneously
- Ensures data consistency - exactly one current record, never zero or multiple
- Maintains clean history with clear "latest state" vs. "historical states"
- Simple query pattern: `DeviceFacts.objects.filter(device=device, is_current=True)`

**Implementation:**
```python
@transaction.atomic
def _save_facts_atomically(device, facts_data):
    # Mark all existing records as non-current
    DeviceFacts.objects.filter(device=device, is_current=True).update(is_current=False)
    # Create new current record
    facts = DeviceFacts.objects.create(device=device, is_current=True, ...)
    return facts
```

**Why this matters:**
- Without atomic update: Two concurrent collections could both mark themselves as current
- With atomic update: Database transaction ensures one completes before the other starts
- Historical records preserved with `is_current=False` for analysis

---

### Why Error Message Sanitization

**Decision:** Sanitize all error messages to remove credentials before database storage or UI display

**Rationale:**
- Security requirement: credentials must never leak to logs, database, or UI
- Defense in depth: sanitize at multiple layers (logging filter, error handler, database save)
- Regulatory compliance: prevent credential exposure in audit logs or database exports

**Implementation:**
- `logging_filters.py`: Regex-based log sanitization applied at logger level
- `error_messages.py`: Additional sanitization for database storage
- Patterns matched: `password=value`, `username=value`, SSH connection strings, environment variable names

**Sanitization patterns:**
```python
password=secret123     → password='******'
username=admin         → username='[REDACTED]'
ssh://admin:pass@host  → ssh://[REDACTED]:[REDACTED]@host
NETOPS_PASSWORD_1      → NETOPS_PASSWORD_[N]
```

**Why user-friendly messages:**
- Raw exceptions expose technical details that confuse operators
- Actionable guidance helps operators self-service common issues
- Maps exception types to specific troubleshooting steps

---

### Why Connection Outside Transaction

**Decision:** SSH connection happens outside database transaction; only database writes are transactional

**Rationale:**
- SSH operations take 5-30+ seconds (slow network I/O)
- Holding database locks during SSH operations blocks other queries
- Transaction should be as short as possible for performance
- SSH is idempotent - can be retried without side effects

**Implementation pattern:**
```python
def collect_facts(device):
    # OUTSIDE transaction - no DB locks held during SSH
    with DeviceConnector(device) as connector:
        credential_index = connector.connect()
        raw_facts = connector.get_driver().get_facts()

    # Extract facts (pure function, fast)
    normalized_facts = extract_facts(raw_facts, platform_slug)

    # INSIDE transaction - fast database write
    facts_record = _save_facts_atomically(device, normalized_facts)
```

**Benefits:**
- No lock contention - other queries can proceed during SSH operations
- Fast transaction - database write takes milliseconds
- Better scalability - multiple concurrent collections don't block each other

---

## Advanced Configuration

### Multiple Credential Sets

The plugin supports up to 10 credential sets via environment variables. Credential sets are tried in order until one succeeds.

**Environment variable pattern:**
```bash
NETOPS_USERNAME_1=primary_user
NETOPS_PASSWORD_1=primary_pass

NETOPS_USERNAME_2=backup_user
NETOPS_PASSWORD_2=backup_pass

NETOPS_USERNAME_3=readonly_user
NETOPS_PASSWORD_3=readonly_pass
```

**Fallback behavior:**
1. Try credential set 1 (or last successful credential if available)
2. If authentication fails, try credential set 2
3. Continue until success or all credentials exhausted
4. If timeout or network error, abort immediately (no credential fallback)

**Best practices:**
- Order credentials by likelihood of success (most common first)
- Include read-only credentials as final fallback
- Rotate credentials regularly without plugin restart (credential memory updates automatically)
- Test credentials manually via SSH before configuring plugin

---

### SSH Algorithm Configuration

The plugin enables legacy SSH algorithms automatically to support aging network devices (Cisco IOS 12.x, old NXOS).

**Algorithms enabled by disabling modern ones:**

Key Exchange (KEX):
- `diffie-hellman-group1-sha1` (legacy, weak)
- `diffie-hellman-group14-sha1` (legacy, moderate)
- Modern algorithms disabled to force fallback: curve25519, group-exchange-sha256, group16, group18

Host Keys:
- `ssh-rsa` (legacy)
- `ssh-dss` (legacy, very weak)
- Modern algorithms disabled: rsa-sha2-512, rsa-sha2-256

**Why disable modern to enable legacy:**
Paramiko (underlying SSH library) prefers modern algorithms by default. Disabling modern algorithms forces negotiation to fall back to legacy algorithms supported by aging devices.

**Security implications:**
- Legacy algorithms have known weaknesses (see [DEPLOYMENT.md](DEPLOYMENT.md) for mitigations)
- Use network segmentation to isolate plugin from untrusted networks
- Consider upgrading device firmware to support modern algorithms

**Configuration location:**
See `connection.py` → `DeviceConnector._get_optional_args()` → `disabled_algorithms` parameter

**Troubleshooting crypto errors:**
If connection still fails with "algorithm negotiation failed":
1. Check device SSH configuration: `show ssh` (Cisco) or `show configuration system services ssh` (Juniper)
2. Verify device supports at least one enabled algorithm
3. Check NetBox logs for attempted algorithms: `docker-compose logs netbox | grep KEX`
4. Consider system-level SSH configuration if device requires extremely old algorithms

---

### Platform Support

**Supported platforms:**

| Platform Slug | NAPALM Driver | Vendor | Notes |
|--------------|---------------|--------|-------|
| `cisco_ios` | `ios` | Cisco | IOS and IOS-XE use same driver |
| `cisco_iosxe` | `ios` | Cisco | Alias for cisco_ios |
| `cisco_nxos` | `nxos_ssh` | Cisco | SSH transport only (no NX-API) |
| `juniper_junos` | `junos` | Juniper | JunOS 12.x and later |

**Adding new platforms:**

1. Verify NAPALM driver exists: https://napalm.readthedocs.io/en/latest/support/
2. Add mapping to `platforms.py` → `PLATFORM_DRIVER_MAP`
3. Add platform slug to `facts_collection.py` → `SUPPORTED_PLATFORMS`
4. Create platform-specific extractor in `facts_extraction.py` if needed (for quirks)
5. Update routing logic in `extract_facts()` function
6. Test collection with real device before production

**Platform-specific quirks:**

- **JunOS:** May return `null` hostname from NAPALM. Extractor converts to empty string.
- **Cisco:** Vendor returned as "Cisco Systems" or "Cisco Systems, Inc." - normalized to "Cisco"
- **NXOS:** Uses `nxos_ssh` driver (not `nxos`) to force SSH transport

---

### Timeout and Retry Configuration

**Connection timeout:**
```python
CONNECTION_TIMEOUT = 30  # seconds
```

Configurable in `connection.py`. Increase for slow networks or heavily loaded devices.

**Retry behavior:**
```python
MAX_TIMEOUT_RETRIES = 1  # retry once on timeout
```

- Timeout triggers one retry with same credential
- Authentication failure triggers immediate credential fallback (no retry)
- Network error triggers immediate abort (no retry, no credential fallback)

**When to adjust:**
- Increase timeout if devices consistently timeout (check network latency first)
- Increase retries if transient network issues common (e.g., over-subscribed links)
- Decrease timeout if willing to fail fast on unreachable devices

---

## Troubleshooting

This section covers common issues with symptom, cause, diagnosis, solution, and prevention guidance.

---

### Installation Issues

#### Issue: Plugin not appearing in NetBox

**Symptom:** Plugin not visible at `/plugins/` or in navigation menu

**Cause:** Plugin not added to `PLUGINS` configuration or not installed in Python environment

**Diagnosis:**
```bash
# Check if plugin in PLUGINS list
docker-compose exec netbox python -c "from django.conf import settings; print(settings.PLUGINS)"

# Check if plugin installed in Python
docker-compose exec netbox pip list | grep netbox-network-ops
```

**Solution:**
1. Add `'netbox_network_ops'` to `PLUGINS` list in `configuration.py`
2. Restart NetBox: `docker-compose restart netbox worker`

**Prevention:** Always verify `PLUGINS` configuration after adding new plugins. Use configuration management (Ansible, etc.) for consistency.

---

#### Issue: "No module named netbox_network_ops"

**Symptom:** ImportError during NetBox startup in logs

**Cause:** Plugin package not installed in NetBox container's Python environment

**Diagnosis:**
```bash
# Check plugin installed
docker-compose exec netbox pip list | grep netbox-network-ops

# Check if plugin accessible
docker-compose exec netbox python -c "import netbox_network_ops; print(netbox_network_ops.__version__)"
```

**Solution:**
- **Development:** Verify volume mount in `docker-compose.yml` points to plugin directory
- **Production:** Install via pip: `pip install netbox-network-ops`
- **Docker:** Add to `plugin_requirements.txt` and rebuild container

**Prevention:** Use `plugin_requirements.txt` for Docker deployments. Pin version numbers for reproducibility.

---

#### Issue: Migration errors

**Symptom:** Database errors mentioning `netbox_network_ops` tables or columns

**Cause:** Database migrations not applied after plugin installation

**Diagnosis:**
```bash
# Check migration status
docker-compose exec netbox python manage.py showmigrations netbox_network_ops

# Look for [ ] (not applied) vs [X] (applied)
```

**Solution:**
```bash
# Apply migrations
docker-compose exec netbox python manage.py migrate netbox_network_ops

# Verify
docker-compose exec netbox python manage.py showmigrations netbox_network_ops
```

**Prevention:** Always run migrations after plugin installation or upgrade. Automate with deployment scripts.

---

### Credential Issues

#### Issue: "No valid credentials configured"

**Symptom:** Plugin startup fails with `ImproperlyConfigured` error

**Cause:** Required environment variables `NETOPS_USERNAME_1` and `NETOPS_PASSWORD_1` not set

**Diagnosis:**
```bash
# Check environment variables
docker-compose exec netbox env | grep NETOPS

# Check environment file
cat env/netbox.env | grep NETOPS
```

**Solution:**
1. Add to `env/netbox.env`:
   ```bash
   NETOPS_USERNAME_1=your_username
   NETOPS_PASSWORD_1=your_password
   ```
2. Restart NetBox: `docker-compose restart netbox worker`

**Prevention:** Use environment variable template with all required variables documented. Validate in CI/CD pipeline.

---

#### Issue: "Authentication failed" for all devices

**Symptom:** All collection attempts fail with authentication error, regardless of device

**Cause:** Wrong credentials or incorrect credential format in environment variables

**Diagnosis:**
```bash
# Test SSH manually with configured credentials
ssh username@device_ip

# Check for common issues:
# - Extra whitespace in environment variables
# - Special characters requiring escaping
# - Copy-paste errors
# - Password expiration
```

**Solution:**
1. Verify credentials work via manual SSH
2. Check environment variable values for typos
3. Update credentials in `env/netbox.env`
4. Restart NetBox: `docker-compose restart netbox worker`

**Prevention:**
- Test credentials before configuring plugin
- Use credential rotation automation
- Document credential format requirements
- Set up monitoring for authentication failures

---

#### Issue: Passwords appearing in logs (SECURITY)

**Symptom:** Credential values visible in log output or database

**Cause:** Critical security bug - report immediately if this occurs

**Diagnosis:**
```bash
# Check logs for credential exposure (should find nothing)
docker-compose logs netbox 2>&1 | grep -i "password\|passwd"

# Check database for credential exposure
docker-compose exec netbox python manage.py shell
>>> from netbox_network_ops.models import DeviceFacts
>>> facts = DeviceFacts.objects.filter(error_message__icontains='password')
>>> # Should return empty queryset
```

**Solution:**
This should never happen. If it does:
1. Immediately rotate all credentials
2. File security issue on GitHub (or contact maintainer privately)
3. Review logs to determine exposure scope
4. Document incident for security audit

**Prevention:**
- Log sanitization is automatic - do not disable
- Never log credentials manually in custom code
- Review code changes for credential exposure risks
- Regular security audits of logging configuration

---

### Connection Issues

#### Issue: "Connection timeout after 30s"

**Symptom:** Collection fails with timeout error, no facts collected

**Cause:** Device unreachable via network, SSH not responding, or device overloaded

**Diagnosis:**
```bash
# Check network connectivity
ping device_ip

# Check SSH port accessible
nc -zv device_ip 22
# Should show: Connection to device_ip 22 port [tcp/ssh] succeeded!

# Check from NetBox container
docker-compose exec netbox ping -c 3 device_ip
docker-compose exec netbox nc -zv device_ip 22
```

**Solution:**
1. Verify device IP address correct in NetBox
2. Check network path: routing, firewall rules, ACLs
3. Verify SSH service running on device:
   - Cisco: `show ip ssh`
   - Juniper: `show configuration system services ssh`
4. Check device load: high CPU can cause SSH timeouts

**Prevention:**
- Ensure management network path from NetBox to devices
- Monitor device CPU/memory
- Use out-of-band management network for reliability
- Implement network monitoring to detect connectivity issues proactively

---

#### Issue: "Connection refused"

**Symptom:** Collection fails immediately with "Connection refused" error

**Cause:** SSH service not running on device, or firewall blocking port 22

**Diagnosis:**
```bash
# Check SSH port open
nc -zv device_ip 22

# If fails, SSH not accepting connections
```

**Solution:**
1. Enable SSH on device:
   - Cisco: `crypto key generate rsa` + `ip ssh version 2` + `line vty 0 4` + `transport input ssh`
   - Juniper: `set system services ssh`
2. Check firewall rules:
   - Device ACL blocking NetBox source IP
   - Network firewall blocking SSH traffic
3. Verify correct port (default 22):
   - Some devices use non-standard SSH port
   - NAPALM assumes port 22 (not currently configurable in plugin)

**Prevention:**
- Document SSH enablement in device provisioning checklist
- Use configuration management to ensure SSH enabled
- Regularly audit SSH accessibility across device inventory

---

#### Issue: "SSH algorithm negotiation failed"

**Symptom:** Connection fails with crypto-related error message containing "key exchange", "no matching", or "algorithm"

**Cause:** Device requires SSH algorithms not enabled by default in Paramiko

**Diagnosis:**
```bash
# Check error message for algorithm details
docker-compose logs netbox | grep -A 5 "algorithm"

# Check device SSH algorithms
# Cisco: show ip ssh
# Juniper: show configuration system services ssh

# Compare with enabled algorithms in connection.py
```

**Solution:**
The plugin enables legacy SSH algorithms automatically. If still failing:

1. Verify device supports at least one enabled algorithm:
   - KEX: diffie-hellman-group1-sha1 or diffie-hellman-group14-sha1
   - Host key: ssh-rsa or ssh-dss
2. If device requires extremely old algorithms not supported by Paramiko:
   - Update device firmware (preferred)
   - Use external SSH proxy that supports older algorithms
   - Contact maintainer to add additional algorithm support
3. Check for conflicting system-level SSH configuration:
   - Paramiko does NOT read system SSH config files
   - All configuration must be in plugin code

**Prevention:**
- Document supported SSH algorithms in device standards
- Plan firmware upgrades for devices with very old SSH versions
- Test SSH connectivity during device onboarding

---

#### Issue: "Host key verification failed"

**Symptom:** SSH connection rejected due to host key verification

**Cause:** This should NOT happen - plugin disables strict host key checking via `ssh_strict=False`

**Diagnosis:**
```bash
# Check connection.py for ssh_strict setting
grep -A 3 "optional_args" netbox_network_ops/connection.py

# Verify ssh_strict=False present
```

**Solution:**
1. Verify plugin code hasn't been modified (check `connection.py`)
2. If code is correct, this may be a Paramiko bug - report issue
3. Temporary workaround: Pre-populate known_hosts (not recommended)

**Prevention:** Don't modify `connection.py` optional_args without understanding implications

---

### Platform Issues

#### Issue: "Platform 'xyz' is not supported"

**Symptom:** Collection fails with unsupported platform error

**Cause:** Device has platform slug not in `SUPPORTED_PLATFORMS` list

**Diagnosis:**
```bash
# Check device platform in NetBox
# Navigate to device detail page → Platform field

# Check supported platforms
grep "SUPPORTED_PLATFORMS" netbox_network_ops/facts_collection.py
```

**Solution:**
1. Change device platform to supported slug:
   - `cisco_ios` (IOS and IOS-XE)
   - `cisco_iosxe` (alias for cisco_ios)
   - `cisco_nxos` (NXOS)
   - `juniper_junos` (JunOS)
2. Or add support for new platform (see [Advanced Configuration](#platform-support))

**Prevention:**
- Use standard platform slugs in NetBox
- Document supported platforms in device provisioning guide
- Create NetBox custom validation rules to enforce supported platforms

---

#### Issue: "Device has no platform assigned"

**Symptom:** Collection fails with "no platform" error message

**Cause:** Device missing platform assignment in NetBox

**Diagnosis:**
```bash
# Check device in NetBox
# Navigate to device detail page → Platform field should be empty
```

**Solution:**
1. Edit device in NetBox
2. Assign appropriate platform from supported list
3. Retry collection

**Prevention:**
- Make platform a required field in device creation workflow
- Use NetBox custom validators to enforce platform assignment
- Regular audit reports for devices missing platform

---

#### Issue: Device not appearing in dropdown

**Symptom:** Device exists in NetBox but not visible in plugin's device selection dropdown

**Cause:** Device missing Primary IPv4 address or unsupported platform

**Diagnosis:**
```bash
# Check device requirements:
# 1. Must have Primary IPv4 set (Management > Primary IPv4)
# 2. Must have supported platform assigned
# 3. Must be in active status

# Navigate to device in NetBox and verify these fields
```

**Solution:**
1. Assign Primary IPv4 address to device
2. Verify platform is supported (see supported platforms above)
3. Verify device status is active

**Prevention:**
- Document requirements for plugin-eligible devices
- Create NetBox reports to identify devices missing primary IP or platform
- Use custom fields or tags to track plugin compatibility

---

### Background Job Issues

#### Issue: Jobs stuck in "pending"

**Symptom:** Collection triggered but job never progresses beyond "pending" status

**Cause:** RQ worker not running or not processing jobs

**Diagnosis:**
```bash
# Check worker container status
docker-compose ps worker
# Should show "Up" status

# Check worker logs
docker-compose logs worker
# Should show "Listening on default queue"

# Check RQ stats
docker-compose exec netbox python manage.py rqstats
# Should show workers and queue status
```

**Solution:**
1. Start worker if not running: `docker-compose up -d worker`
2. Restart worker if hung: `docker-compose restart worker`
3. Check Redis connectivity: `docker-compose exec netbox python manage.py rqstats`

**Prevention:**
- Monitor worker health (process monitoring, health checks)
- Configure worker autorestart (systemd, supervisord)
- Set up alerting for queue backlog

---

#### Issue: Jobs always "errored"

**Symptom:** Jobs fail with "errored" status (not "failed") and show stack trace

**Cause:** Unexpected exception in collection code or configuration issue

**Diagnosis:**
```bash
# Check job error in NetBox admin
# Navigate to: Admin → Background Jobs → Job History → View job

# Check worker logs for full traceback
docker-compose logs worker | grep -A 20 "Traceback"

# Common causes:
# - Missing NAPALM dependency
# - Incorrect platform mapping
# - Database migration not applied
# - Permission issues
```

**Solution:**
1. Review error message and stack trace
2. Fix underlying configuration issue
3. Check Prerequisites:
   - NAPALM installed: `pip list | grep napalm`
   - Migrations applied: `python manage.py showmigrations netbox_network_ops`
   - Credentials configured: `env | grep NETOPS`

**Prevention:**
- Test collection manually before production deployment
- Set up monitoring for errored jobs
- Implement alerting for repeated failures
- Regular plugin health checks

---

#### Issue: Progress not updating

**Symptom:** UI shows "pending" but job is actually running or completed

**Cause:** JavaScript polling issue, browser caching, or network problem

**Diagnosis:**
```bash
# Check job status in database
docker-compose exec netbox python manage.py shell
>>> from core.models import Job
>>> job = Job.objects.get(id='<job_id>')
>>> print(job.status, job.data)

# Check browser console for errors
# Open browser DevTools → Console
# Look for fetch errors, AJAX errors, or JavaScript exceptions

# Check network tab
# DevTools → Network → Filter "status" → Should show polling requests every 5s
```

**Solution:**
1. Refresh page to restart polling
2. Clear browser cache and retry
3. Check browser console for JavaScript errors
4. Verify `/api/plugins/network-ops/jobs/{job_id}/status/` endpoint accessible

**Prevention:**
- Test polling across different browsers
- Implement timeout for polling (stop after X failed attempts)
- Add user-visible error messages for polling failures

---

### Data Issues

#### Issue: Mismatches not highlighting

**Symptom:** NetBox data differs from device facts but no visual indication in UI

**Cause:** Normalization differences or comparison logic bug

**Diagnosis:**
```bash
# Check raw values in database
docker-compose exec netbox python manage.py shell
>>> from dcim.models import Device
>>> from netbox_network_ops.models import DeviceFacts
>>> device = Device.objects.get(name='device-name')
>>> facts = device.facts_history.filter(is_current=True).first()
>>> print(f"NetBox: {device.name}")
>>> print(f"Device: {facts.hostname}")

# Check normalization logic in template
# Look at device_facts.html → mismatch detection logic
```

**Solution:**
1. Verify comparison uses normalized values (lowercase, stripped whitespace)
2. Check for vendor-specific normalization (e.g., "Cisco Systems" → "Cisco")
3. Review template logic: `{% if netbox_value|lower != device_value|lower %}`

**Prevention:**
- Unit tests for normalization logic
- Document normalization rules
- Test with real device data from production

---

#### Issue: JunOS devices show blank hostname

**Symptom:** JunOS devices collect successfully but hostname field empty

**Cause:** JunOS sometimes returns `null` hostname from NAPALM `get_facts()`

**Diagnosis:**
```bash
# Check raw NAPALM output
docker-compose exec netbox python manage.py shell
>>> from napalm import get_network_driver
>>> driver = get_network_driver('junos')
>>> device = driver(hostname='device_ip', username='user', password='pass')
>>> device.open()
>>> facts = device.get_facts()
>>> print(facts['hostname'])
# Will show: None
```

**Solution:**
This is expected behavior, not a bug:
- Plugin handles this automatically in `extract_junos_facts()`
- `None` hostname converted to empty string
- Empty string displayed in UI as blank
- No error recorded

**Why this happens:**
- JunOS devices with unconfigured hostname return `null`
- NAPALM returns exactly what device provides
- Not a collection failure - just missing data on device

**Prevention:**
- Configure hostname on JunOS devices: `set system host-name device-name`
- Document that hostname is optional field (may be empty)

---

## API Reference

### Job Status Endpoint

**GET** `/api/plugins/network-ops/jobs/<job_id>/status/`

Returns current status of background job.

**Parameters:**
- `job_id` (UUID): Job identifier returned from collection trigger

**Response (Success):**
```json
{
    "status": "completed",
    "progress": 100,
    "step": "Completed",
    "message": "Facts collected successfully",
    "device_name": "router-1",
    "device_id": 123
}
```

**Response (Failed):**
```json
{
    "status": "failed",
    "progress": 100,
    "step": "Failed",
    "message": "Authentication failed. Verify credentials...",
    "error": "Authentication failed for router-1",
    "device_name": "router-1",
    "device_id": 123
}
```

**Response (In Progress):**
```json
{
    "status": "running",
    "progress": 50,
    "step": "Retrieving facts",
    "message": "Collecting facts from device",
    "device_name": "router-1",
    "device_id": 123
}
```

**Response (Not Found):**
```json
{
    "error": "Job not found"
}
```
HTTP Status: 404

**Response (Invalid UUID):**
```json
{
    "error": "Invalid job ID format"
}
```
HTTP Status: 400

---

### Trigger Collection Endpoint

**POST** `/plugins/network-ops/collect-facts/<device_id>/`

Triggers background job to collect facts from device.

**Parameters:**
- `device_id` (int): NetBox device ID

**Response (Success):**
```json
{
    "status": "success",
    "job_id": "550e8400-e29b-41d4-a716-446655440000",
    "device_name": "router-1"
}
```

**Response (Error):**
```json
{
    "status": "error",
    "error": "Device not found"
}
```
HTTP Status: 404

---

## FAQ

### General Questions

**Q: How long does facts collection take?**

A: Typically 5-30 seconds depending on:
- Network latency between NetBox and device
- Device CPU load (busy devices respond slower)
- SSH algorithm negotiation (legacy algorithms slower)
- Credential fallback (additional attempts add time)

**Q: Can I collect from multiple devices at once?**

A: Not in v1. Each collection is single-device. Bulk collection (select multiple devices, trigger all) planned for future version.

**Q: Why does collection sometimes take longer than other times?**

A: Several factors cause variability:
- Credential memory: First connection tries all credentials, subsequent connections try successful credential first (faster)
- Network conditions: Packet loss or high latency increases connection time
- Device load: High CPU/memory on device slows SSH responses
- Algorithm negotiation: Trying multiple SSH algorithms adds overhead

---

### Credential Questions

**Q: Why do I need multiple credential sets?**

A: Different devices may have different credentials:
- Production devices use production credentials
- Lab devices use lab credentials
- Legacy devices use old credential format
- Security zones require zone-specific credentials

Fallback ensures collection works across heterogeneous environments without manual per-device configuration.

**Q: How many credential sets can I configure?**

A: Up to 10 credential sets (1-10). Most environments use 2-3.

**Q: Can I configure per-device credentials?**

A: No, credentials are environment-wide. This is intentional:
- Prevents credential exposure in database
- Simplifies credential rotation
- Aligns with operational security practices

Future enhancement: NetBox Secrets integration for per-device credentials

**Q: How do I rotate credentials?**

A: Update environment variables and restart NetBox:
1. Update `env/netbox.env` with new credentials
2. Restart: `docker-compose restart netbox worker`
3. Plugin automatically uses new credentials
4. Credential memory updates as devices successfully authenticate with new credentials

---

### Security Questions

**Q: Are credentials encrypted in transit?**

A: Yes, SSH encrypts all communication with devices. Credentials never transmitted in plaintext.

**Q: Are credentials encrypted at rest?**

A: Credentials stored in environment variables (not database). Encryption depends on your environment:
- Environment files: Encrypt with SOPS, Vault, or similar
- Container secrets: Use Docker secrets or Kubernetes secrets
- VM environment: Protect with filesystem permissions

**Q: Is data encrypted in the database?**

A: Device facts stored in plaintext in NetBox database. Database encryption depends on your NetBox deployment:
- Use database-level encryption (PostgreSQL TDE)
- Use filesystem-level encryption (LUKS, dm-crypt)
- Follow your organization's data protection standards

**Q: What SSH algorithms are enabled?**

A: Plugin enables legacy SSH algorithms to support aging devices:
- KEX: diffie-hellman-group1-sha1, diffie-hellman-group14-sha1
- Host keys: ssh-rsa, ssh-dss
- These algorithms have known weaknesses - see [DEPLOYMENT.md](DEPLOYMENT.md) for security mitigations

**Q: Can I disable legacy SSH algorithms?**

A: Yes, edit `connection.py` → `_get_optional_args()` → remove algorithms from `disabled_algorithms`.

**Warning:** Disabling legacy algorithms will break connectivity to aging devices that don't support modern algorithms.

---

### Platform Questions

**Q: What platforms are supported?**

A: Currently:
- Cisco IOS
- Cisco IOS-XE
- Cisco NXOS
- Juniper JunOS

**Q: Can I add support for new platforms?**

A: Yes, if NAPALM driver exists. See [Advanced Configuration > Platform Support](#platform-support) for instructions.

**Q: Why doesn't my device appear in the dropdown?**

A: Device must meet these requirements:
1. Has Primary IPv4 address assigned
2. Has supported platform assigned
3. Is in active status

Check device in NetBox and verify these fields.

**Q: Can I use custom platform slugs?**

A: No, plugin requires exact platform slugs: `cisco_ios`, `cisco_iosxe`, `cisco_nxos`, `juniper_junos`. This ensures consistent driver mapping.

Future enhancement: Custom platform mapping configuration

---

### Data Questions

**Q: How often should I collect facts?**

A: Depends on your use case:
- Initial device validation: Collect once during onboarding
- Regular audits: Collect weekly/monthly
- Change validation: Collect after configuration changes
- Incident investigation: Collect on-demand

**Q: Are historical facts saved?**

A: Yes, all facts records saved with `is_current=False`. Only latest record marked `is_current=True`. Query historical records via `device.facts_history.all()`.

**Q: Can I export facts data?**

A: Yes, via NetBox API or database query:
- REST API: `/api/plugins/network-ops/facts/`
- GraphQL: Query `DeviceFacts` type
- Database: Query `netbox_network_ops_devicefacts` table

**Q: What happens if collection fails?**

A: Failed collection creates `DeviceFacts` record with:
- `collection_status` = "failed"
- `error_message` = User-friendly error message
- All facts fields empty
- `is_current` = True (marks as latest attempt)

Previous successful facts preserved as historical records (`is_current=False`).

---

### Troubleshooting Questions

**Q: Collection worked yesterday, fails today - what changed?**

A: Common causes:
- Credentials rotated but environment variables not updated
- Device rebooted and SSH not enabled
- Network path changed (routing, firewall rules)
- Device firmware upgraded and SSH configuration changed

**Q: Some devices work, others fail - why?**

A: Likely credential or platform differences:
- Failed devices use different credentials
- Failed devices have unsupported platform
- Failed devices have stricter SSH configuration
- Network path differs (some devices behind firewall)

Check error message for specific failure reason.

**Q: Collection succeeds but shows no data - why?**

A: Check for:
- JunOS device with unconfigured hostname (expected - see [Data Issues](#issue-junos-devices-show-blank-hostname))
- NAPALM driver returned empty dict (NAPALM bug or device issue)
- Extraction logic filtered out data (check `facts_extraction.py`)

**Q: How do I debug connection issues?**

A: Step-by-step diagnosis:
1. Verify device reachable: `ping device_ip`
2. Verify SSH port open: `nc -zv device_ip 22`
3. Test manual SSH: `ssh username@device_ip`
4. Check worker logs: `docker-compose logs worker`
5. Check NetBox logs: `docker-compose logs netbox`
6. Enable debug logging: Set `LOG_LEVEL=DEBUG` in environment

---

### Operational Questions

**Q: Does the plugin affect NetBox performance?**

A: Minimal impact:
- Facts stored in separate table (not core NetBox models)
- Collection happens in background (doesn't block web workers)
- Database writes are fast (<100ms)
- Only impact: RQ worker CPU during active collections

**Q: How do I monitor plugin health?**

A: Monitor these metrics:
- Job failure rate (target: <5%)
- Job duration (target: <30s p95)
- Queue backlog (target: <10 jobs)
- Worker process status (target: always running)
- Error message frequency (identify systemic issues)

**Q: Can I use the plugin in production?**

A: Yes, plugin is production-ready:
- Atomic database transactions prevent corruption
- Credential sanitization prevents exposure
- Error handling prevents crashes
- Background jobs prevent blocking
- Historical tracking provides audit trail

**Q: How do I upgrade the plugin?**

A: Standard NetBox plugin upgrade process:
1. Backup database
2. Install new version: `pip install --upgrade netbox-network-ops`
3. Apply migrations: `python manage.py migrate netbox_network_ops`
4. Restart NetBox: `docker-compose restart netbox worker`
5. Test collection on single device before bulk use

---

## Contributing

Found a bug? Have a feature request? Want to contribute code?

See [GitHub repository](https://github.com/YOUR_USERNAME/netbox-network-ops) for:
- Issue tracker
- Pull request guidelines
- Development setup guide
- Contribution workflow

---

## License

See [LICENSE](LICENSE) file for details.

---

## Support

- Documentation: This file, [SETUP_GUIDE.md](SETUP_GUIDE.md), [DEPLOYMENT.md](DEPLOYMENT.md)
- Issues: GitHub issue tracker
- Security: Report security issues privately to maintainer

---

*Last updated: 2026-01-29*
