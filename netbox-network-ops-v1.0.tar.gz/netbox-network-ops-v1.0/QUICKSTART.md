# Quick Start Guide

Get the NetBox Network Operations Plugin running in 5 minutes.

## Prerequisites

- NetBox 4.0.0 or higher installed
- SSH access to network devices
- Device credentials (username/password)
- Devices configured in NetBox with `primary_ip4` assigned

## Installation (Docker)

1. **Install the plugin:**
   ```bash
   docker exec netbox pip install /path/to/netbox-network-ops-v1.0
   ```

2. **Add to configuration.py:**
   ```python
   PLUGINS = [
       'netbox_network_ops',
   ]
   ```

3. **Set credentials in environment (netbox.env):**
   ```bash
   NETOPS_USERNAME_1=your_username
   NETOPS_PASSWORD_1=your_password
   ```

4. **Run migrations:**
   ```bash
   docker exec netbox python manage.py migrate netbox_network_ops
   ```

5. **Restart NetBox:**
   ```bash
   docker-compose restart netbox worker
   ```

## First Collection

1. Navigate to **Plugins → Network Operations** in NetBox UI

2. Select a device from the dropdown (must have primary_ip4)

3. Click **Collect Facts** button

4. Watch real-time progress updates

5. View facts comparison:
   - **Left column:** NetBox data (source of truth)
   - **Right column:** Device facts (actual state)
   - **Yellow highlighting:** Mismatches detected

## Credential Fallback

Configure multiple credential sets for automatic fallback:

```bash
# Primary credentials (tried first)
NETOPS_USERNAME_1=admin
NETOPS_PASSWORD_1=admin_password

# Backup credentials (tried if primary fails)
NETOPS_USERNAME_2=readonly
NETOPS_PASSWORD_2=readonly_password
```

The plugin will try credentials in order and remember which one worked for faster future connections.

## Troubleshooting

### Plugin not appearing
```bash
# Verify installation
docker exec netbox pip list | grep netbox-network-ops

# Check for errors
docker logs netbox
```

### "No valid credentials configured"
```bash
# Verify environment variables
docker exec netbox env | grep NETOPS

# Check Django system checks
docker exec netbox python manage.py check netbox_network_ops
```

### "Connection timeout"
- Verify device is SSH-reachable: `ssh user@device-ip`
- Check firewall rules between NetBox and device
- Increase timeout if needed (default: 30 seconds)

### Device not in dropdown
- Ensure device has `primary_ip4` assigned in NetBox
- Verify device platform is set and supported
- Refresh page after assigning IP

## Platform Support

Ensure NetBox device platform slug matches one of:
- `cisco_ios` or `ios` → Cisco IOS/IOS-XE
- `cisco_nxos` or `nxos` → Cisco NXOS
- `juniper_junos` or `junos` → Juniper JunOS

## Next Steps

- **Full documentation:** See `DOCUMENTATION.md`
- **Production deployment:** See `DEPLOYMENT.md`
- **Architecture details:** See `README.md`

## Support

For issues or questions:
1. Check `DOCUMENTATION.md` troubleshooting section
2. Review NetBox logs: `docker logs -f netbox`
3. Check RQ worker logs: `docker logs -f worker`
4. Open issue on GitHub repository

---

**Quick tip:** The plugin caches facts and shows staleness warnings after 24 hours. Use "Collect Facts" to refresh on demand.
