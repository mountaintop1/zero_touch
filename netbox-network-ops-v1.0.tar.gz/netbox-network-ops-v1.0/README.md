# NetBox Network Operations Plugin

Collect and display live device facts from network devices via SSH. Verify that NetBox inventory data matches actual device state.

## Features

- **On-demand facts collection** - Retrieve live device data via NAPALM without manual SSH sessions
- **Multi-vendor support** - Cisco IOS, IOS-XE, NXOS, and Juniper JunOS platforms
- **Credential fallback** - Automatically tries multiple credential sets on authentication failure
- **Background job execution** - Non-blocking collection with real-time progress updates
- **Side-by-side comparison** - Compare NetBox data with actual device facts to detect drift
- **Historical tracking** - Maintains collection history with timestamps for audit trails
- **Legacy SSH support** - Connects to older devices with weak cryptographic algorithms
- **Credential memory** - Remembers which credentials succeeded for faster reconnection

## Compatibility

| NetBox Version | Plugin Version |
|----------------|----------------|
| 4.0.x          | 0.1.x          |

**Requirements:**
- NetBox 4.0 or later
- Python 3.8 or later
- SSH access to network devices
- RQ worker for background jobs

## Installation

### Docker Installation (Recommended)

This is the recommended method for production NetBox deployments using Docker.

**1. Configure environment variables**

Add to `docker-compose.override.yml` (or your environment file):

```yaml
version: '3.8'

services:
  netbox:
    environment:
      - NETOPS_USERNAME_1=admin
      - NETOPS_PASSWORD_1=your_secure_password

  worker:
    environment:
      - NETOPS_USERNAME_1=admin
      - NETOPS_PASSWORD_1=your_secure_password
```

**Important:** Both the `netbox` and `worker` containers need the same credentials.

**2. Add plugin to requirements**

Add to `plugin_requirements.txt`:

```
netbox-network-ops
```

**3. Enable the plugin**

Add to your NetBox `configuration.py`:

```python
PLUGINS = [
    'netbox_network_ops',
]
```

**4. Restart containers and apply migrations**

```bash
docker-compose down
docker-compose up -d
docker-compose exec netbox python manage.py migrate netbox_network_ops
```

**5. Verify installation**

Navigate to `http://your-netbox/plugins/network-ops/` and verify the interface loads.

### Manual/Bare Metal Installation

For non-Docker NetBox installations:

**1. Install the plugin**

```bash
# Activate your NetBox virtual environment
source /opt/netbox/venv/bin/activate

# Install the plugin
pip install netbox-network-ops
```

**2. Configure environment variables**

Add to your NetBox environment file (e.g., `/opt/netbox/netbox.env`):

```bash
NETOPS_USERNAME_1=admin
NETOPS_PASSWORD_1=your_secure_password
```

**3. Enable the plugin**

Add to `configuration.py`:

```python
PLUGINS = ['netbox_network_ops']
```

**4. Apply migrations**

```bash
cd /opt/netbox/netbox
python manage.py migrate netbox_network_ops
```

**5. Restart services**

```bash
sudo systemctl restart netbox netbox-rq
```

## Configuration

### Required Environment Variables

At minimum, you must configure one credential set:

| Variable | Description | Example |
|----------|-------------|---------|
| `NETOPS_USERNAME_1` | Primary SSH username | `admin` |
| `NETOPS_PASSWORD_1` | Primary SSH password | `your_password` |

### Optional Environment Variables

For credential fallback (tries in order on authentication failure):

| Variable | Description | Example |
|----------|-------------|---------|
| `NETOPS_USERNAME_2` | Backup SSH username | `readonly` |
| `NETOPS_PASSWORD_2` | Backup SSH password | `backup_pass` |
| `NETOPS_USERNAME_3` | Third credential set | `emergency` |
| `NETOPS_PASSWORD_3` | Third password | `emerg_pass` |

**Security Note:** Credentials are loaded from environment variables only. They are never stored in the database or exposed in the UI.

### Configuration Examples

#### Minimal Configuration (Single Credential)

For simple environments with one credential across all devices:

```bash
# Environment configuration
NETOPS_USERNAME_1=network_admin
NETOPS_PASSWORD_1=secure_password
```

#### Production Configuration (Multiple Credentials)

For complex environments with role-based credentials:

```bash
# Primary administrative credentials
NETOPS_USERNAME_1=primary_admin
NETOPS_PASSWORD_1=primary_secret

# Backup read-only credentials
NETOPS_USERNAME_2=readonly_user
NETOPS_PASSWORD_2=readonly_pass

# Emergency/legacy credentials for older devices
NETOPS_USERNAME_3=legacy_admin
NETOPS_PASSWORD_3=legacy_pass
```

### Credential Fallback Behavior

Understanding how the plugin handles authentication:

1. **Ordered attempts** - Plugin tries credentials in order (1, 2, 3)
2. **Automatic fallback** - On authentication failure, tries the next credential
3. **Credential memory** - Remembers which credential succeeded for each device
4. **Performance optimization** - Next connection tries successful credential first
5. **Error-specific behavior** - On timeout or network error, aborts immediately (no credential fallback)

**Example:** Device initially connects with `NETOPS_USERNAME_2`. On next collection, plugin tries `NETOPS_USERNAME_2` first for faster authentication.

### NetBox Device Requirements

For a device to appear in the plugin interface:

- **Primary IPv4 assigned** - Device must have Management → Primary IPv4 configured
- **Platform assigned** - Device platform must match a supported platform slug (see below)
- **SSH reachable** - Device must be reachable via SSH from the NetBox server

### Platform Configuration

The plugin requires exact platform slugs to map devices to NAPALM drivers.

**In NetBox Admin → DCIM → Platforms, create platforms with these exact slugs:**

| Platform Slug | NAPALM Driver | Vendor | Notes |
|---------------|---------------|--------|-------|
| `cisco_ios` | `ios` | Cisco | IOS devices |
| `cisco_iosxe` | `ios` | Cisco | IOS-XE devices (same driver as IOS) |
| `cisco_nxos` | `nxos_ssh` | Cisco | NXOS devices (SSH-only transport) |
| `juniper_junos` | `junos` | Juniper | JunOS devices |

**Important:** Platform slugs are case-sensitive and must match exactly. Use underscores, not hyphens.

## Usage

### Quick Start

**1. Prepare your devices**

Ensure devices meet the requirements:
- Primary IPv4 address assigned in NetBox
- Platform set to a supported slug (`cisco_ios`, `cisco_nxos`, `cisco_iosxe`, or `juniper_junos`)
- SSH enabled and reachable from NetBox server
- Credentials configured in environment variables match device SSH credentials

**2. Access the plugin**

Navigate to: **Plugins → Network Operations**

**3. Select a device**

Use the dropdown to select a device. The list filters automatically to show only devices with:
- Primary IPv4 assigned
- Supported platform configured

**4. Collect facts**

Click **"Collect Facts"** to retrieve live data from the device.

**5. Review results**

The interface displays:
- **NetBox Data** (left column) - Your source of truth
- **Device Facts** (right column) - Live data from the device
- **Comparison** - Mismatches highlighted in red

### Understanding Collection Status

| Status | Meaning | Next Action |
|--------|---------|-------------|
| **Success** | Facts collected successfully | Review comparison |
| **Pending** | Collection in progress | Wait for job to complete |
| **Failed** | Collection failed | Review error message, check credentials/connectivity |
| **Stale** | Facts older than 24 hours | Click "Refresh Facts" |

### Interpreting Results

**Green rows** - NetBox data matches device facts ✓
**Red rows** - Mismatch detected - investigate which is correct
**Empty device facts** - Data not available from device (normal for some fields)

**Common mismatches:**
- **Hostname** - Device configured name vs. NetBox device name
- **Device Type** - NetBox model vs. actual hardware model
- **OS Version** - NetBox platform version vs. running software version

## Background Jobs

Facts collection runs as background jobs to avoid blocking the NetBox web interface.

### How It Works

1. User clicks "Collect Facts"
2. Job queued to NetBox's RQ worker
3. Worker connects to device via SSH
4. Facts retrieved via NAPALM
5. Results saved to database
6. UI updates automatically via AJAX polling

### Job Progress

The UI polls every 5 seconds and displays:
- **Initializing** (0%) - Job starting
- **Connecting** (25%) - SSH connection in progress
- **Retrieving** (50%) - Fetching facts from device
- **Saving** (75%) - Storing results to database
- **Completed** (100%) - Success or failure

### Monitoring Jobs

View all jobs: **Admin → System → Background Tasks**

### Worker Setup

#### Docker (Automatic)

The worker container runs automatically in standard NetBox Docker deployments. No manual setup required.

**Verify worker is running:**

```bash
docker-compose ps worker
```

**View worker logs:**

```bash
docker-compose logs -f worker
```

**Restart worker (after code changes):**

```bash
docker-compose restart worker
```

#### Bare Metal (Manual)

For non-Docker installations, start the RQ worker manually:

```bash
# Activate NetBox virtual environment
source /opt/netbox/venv/bin/activate

# Start worker
cd /opt/netbox/netbox
python manage.py rqworker default
```

**Production deployment:** Configure as systemd service for automatic startup.

## Development

### Setup Development Environment

**Clone the repository:**

```bash
git clone https://github.com/your-org/netbox-network-ops.git
cd netbox-network-ops
```

**Install in development mode with testing dependencies:**

```bash
pip install -e .[testing]
```

This installs the plugin in editable mode with pytest, pytest-django, pytest-cov, and pytest-mock.

### Running Tests

**Run all tests:**

```bash
pytest
```

**Run with coverage:**

```bash
pytest --cov=netbox_network_ops --cov-report=html
```

**Run specific test file:**

```bash
pytest tests/test_credentials.py
```

**View coverage report:**

```bash
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

### Test Structure

```
tests/
├── conftest.py              # Shared fixtures
├── test_credentials.py      # Credential loading and sanitization
├── test_platforms.py        # Platform-to-driver mapping
├── test_connection.py       # SSH connection management
├── test_extraction.py       # Platform-specific fact extraction
├── test_collection.py       # Facts collection orchestration
├── test_jobs.py             # Background job execution
├── test_views.py            # Django views
├── test_api.py              # REST API endpoints
└── test_integration.py      # End-to-end workflow
```

### Development Workflow

**With Docker development environment:**

See `DEVELOPMENT.md` for detailed Docker-based development setup.

**Key points:**
- Plugin code is volume-mounted into NetBox container
- Changes to Python files require NetBox restart
- Changes to templates are instant (no restart needed)

## Troubleshooting

### Connection Issues

**Error: "Authentication failed"**

1. Verify credentials in environment variables match device SSH credentials
2. Try manual SSH connection: `ssh username@device-ip`
3. Check credential fallback is working (review logs)
4. Verify device AAA configuration accepts the credentials

**Error: "Connection timeout"**

1. Verify device IP is correct in NetBox (Device → Primary IPv4)
2. Test network connectivity: `ping device-ip`
3. Verify SSH port is open: `telnet device-ip 22`
4. Check firewall rules between NetBox and devices
5. Review connection timeout setting (default: 30 seconds)

**Error: "SSH algorithm negotiation failed"**

1. The plugin enables legacy algorithms automatically
2. Check NetBox logs for specific algorithm details
3. Very old devices may need additional algorithms enabled in `connection.py`
4. Verify device SSH server is running: `telnet device-ip 22`

### Platform Issues

**Error: "Unsupported platform"**

1. Verify device platform slug matches exactly: `cisco_ios`, `cisco_nxos`, `cisco_iosxe`, or `juniper_junos`
2. Platform slugs are case-sensitive
3. Check platform mapping in `netbox_network_ops/platforms.py`

**Device not appearing in dropdown:**

1. Verify device has Primary IPv4 assigned
2. Verify device has supported platform assigned
3. Try filtering by region/site to narrow the list

### Worker Issues

**Jobs stuck in "Pending" status:**

1. Verify RQ worker is running: `docker-compose ps worker` (Docker) or check systemd service (bare metal)
2. Check worker logs: `docker-compose logs -f worker`
3. Restart worker: `docker-compose restart worker`

**Jobs failing repeatedly:**

1. Review error message in job details
2. Check NetBox logs: `docker-compose logs netbox`
3. Verify credentials are loaded (check logs on startup)
4. Test SSH connection manually to isolate network/auth issues

### Getting Help

**Check the logs:**

```bash
# NetBox container logs
docker-compose logs -f netbox

# Worker container logs
docker-compose logs -f worker

# View specific job details
NetBox Admin → System → Background Tasks → [Job ID]
```

**Enable debug logging:**

Add to NetBox `configuration.py`:

```python
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'netbox_network_ops': {
            'handlers': ['console'],
            'level': 'DEBUG',
        },
    },
}
```

## Advanced Topics

For advanced topics, see additional documentation:

- **[DEPLOYMENT.md](DEPLOYMENT.md)** - SSH connectivity, legacy algorithm details, production hardening
- **[DEVELOPMENT.md](DEVELOPMENT.md)** - Docker-based development environment setup
- **[SETUP_GUIDE.md](SETUP_GUIDE.md)** - Detailed setup instructions for initial development

## Architecture

### High-Level Flow

```
User clicks "Collect Facts"
    ↓
Job queued to RQ worker
    ↓
Worker connects via SSH (NAPALM)
    ↓
Facts retrieved from device
    ↓
Facts saved to database
    ↓
UI polls for updates
    ↓
Results displayed with comparison
```

### Key Components

- **Platform Layer** (`platforms.py`) - Maps NetBox platform slugs to NAPALM driver names
- **Credentials Layer** (`credentials.py`) - Loads credentials from environment variables
- **Connection Layer** (`connection.py`) - SSH connection management with credential fallback
- **Facts Extraction** (`facts_extraction.py`) - Platform-specific fact normalization
- **Facts Collection** (`facts_collection.py`) - Orchestrates connection → retrieval → storage
- **Background Jobs** (`jobs.py`) - Executes collection asynchronously via RQ
- **API/Views** (`api/views.py`, `views.py`) - REST endpoints and UI views

### Design Principles

- **Credentials never in database** - Environment variables only
- **Atomic database operations** - Facts updates in transactions
- **Connection isolation** - SSH happens outside database transactions
- **Credential memory** - Remembers successful credentials per device
- **Historical tracking** - Multiple facts records per device with timestamps

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass: `pytest`
5. Submit a pull request

**Code style:**
- Follow PEP 8
- Add docstrings to functions
- Keep functions focused and testable
- Add type hints where beneficial

## License

Apache License 2.0

## See Also

- **NetBox Documentation:** https://docs.netbox.dev/
- **NAPALM Documentation:** https://napalm.readthedocs.io/
- **NetBox Plugin Development:** https://github.com/netbox-community/netbox-plugin-tutorial

---

**Version:** 0.1.0
**Maintained by:** Network Operations Team
