# NetBox Network Operations Plugin v1.0 - Deployment Checklist

Use this checklist when deploying to production servers.

## Pre-Deployment

### 1. Environment Verification
- [ ] NetBox 4.0.0+ installed and running
- [ ] Python 3.10+ available
- [ ] RQ worker running (for background jobs)
- [ ] Network connectivity from NetBox to devices
- [ ] SSH access to target devices verified

### 2. Credential Preparation
- [ ] Device credentials identified (username/password)
- [ ] Multiple credential sets prepared (if needed)
- [ ] Credentials stored securely (vault, environment, etc.)
- [ ] Test credentials on sample devices

### 3. Package Verification
- [ ] Downloaded `netbox-network-ops-v1.0.tar.gz`
- [ ] Verified SHA256 checksum:
  ```bash
  shasum -a 256 netbox-network-ops-v1.0.tar.gz
  # Expected: 34e6d2b4a723651b659698adf7df84abc4b34983e64e57520207eceb01b866c8
  ```
- [ ] Extracted tarball:
  ```bash
  tar -xzf netbox-network-ops-v1.0.tar.gz
  ```

## Installation (Docker)

### 4. Copy Package to Server
- [ ] Transfer package to NetBox server:
  ```bash
  scp netbox-network-ops-v1.0.tar.gz user@netbox-server:/opt/
  scp -r netbox-network-ops-v1.0 user@netbox-server:/opt/
  ```

### 5. Install Plugin
- [ ] Extract and install:
  ```bash
  cd /opt
  tar -xzf netbox-network-ops-v1.0.tar.gz
  docker exec netbox pip install /opt/netbox-network-ops-v1.0
  ```
- [ ] Verify installation:
  ```bash
  docker exec netbox pip list | grep netbox-network-ops
  # Expected: netbox-network-ops 1.0.0
  ```

### 6. Configure Credentials
- [ ] Add to `netbox.env` or docker-compose environment:
  ```bash
  # Primary credentials
  NETOPS_USERNAME_1=your_username
  NETOPS_PASSWORD_1=your_secure_password

  # Backup credentials (optional)
  NETOPS_USERNAME_2=backup_username
  NETOPS_PASSWORD_2=backup_password
  ```
- [ ] Restart containers to load environment:
  ```bash
  docker-compose restart netbox worker
  ```

### 7. Enable Plugin
- [ ] Add to NetBox `configuration.py`:
  ```python
  PLUGINS = [
      'netbox_network_ops',
  ]
  ```
- [ ] Restart NetBox:
  ```bash
  docker-compose restart netbox
  ```

### 8. Run Migrations
- [ ] Apply database migrations:
  ```bash
  docker exec netbox python manage.py migrate netbox_network_ops
  ```
- [ ] Verify migration:
  ```bash
  docker exec netbox python manage.py showmigrations netbox_network_ops
  # All migrations should show [X]
  ```

## Installation (Bare Metal)

### 9. Install Plugin (Alternative to Step 5)
- [ ] Activate NetBox virtualenv:
  ```bash
  source /opt/netbox/venv/bin/activate
  ```
- [ ] Install plugin:
  ```bash
  cd /opt/netbox-network-ops-v1.0
  pip install .
  ```

### 10. Configure Credentials (Alternative to Step 6)
- [ ] Add to environment or systemd service:
  ```bash
  # Option A: Add to /opt/netbox/netbox/netbox/configuration.py
  import os
  os.environ['NETOPS_USERNAME_1'] = 'your_username'
  os.environ['NETOPS_PASSWORD_1'] = 'your_password'

  # Option B: Add to systemd service file
  # /etc/systemd/system/netbox.service
  Environment="NETOPS_USERNAME_1=your_username"
  Environment="NETOPS_PASSWORD_1=your_password"
  ```

### 11. Enable and Migrate (Alternative to Steps 7-8)
- [ ] Add to `configuration.py`:
  ```python
  PLUGINS = ['netbox_network_ops']
  ```
- [ ] Run migrations:
  ```bash
  cd /opt/netbox/netbox
  python manage.py migrate netbox_network_ops
  ```
- [ ] Restart services:
  ```bash
  sudo systemctl restart netbox netbox-rq
  ```

## Post-Installation Verification

### 12. System Checks
- [ ] Run Django checks:
  ```bash
  docker exec netbox python manage.py check netbox_network_ops
  # Expected: System check identified no issues (0 silenced).
  ```
- [ ] Check NetBox logs for errors:
  ```bash
  docker logs -f netbox | grep -i error
  ```

### 13. UI Verification
- [ ] Navigate to NetBox UI
- [ ] Verify "Network Operations" appears in plugins menu
- [ ] Click plugin link: `http://your-netbox/plugins/network-ops/`
- [ ] Verify device selection page loads

### 14. Worker Verification
- [ ] Verify RQ worker is running:
  ```bash
  # Docker:
  docker exec worker python manage.py rqworker

  # Bare metal:
  sudo systemctl status netbox-rq
  ```
- [ ] Check worker logs:
  ```bash
  docker logs -f worker
  ```

### 15. First Collection Test
- [ ] Ensure test device exists in NetBox:
  - [ ] Device has `primary_ip4` assigned
  - [ ] Device has platform set (cisco_ios, junos, etc.)
  - [ ] Device is SSH-reachable from NetBox server
- [ ] Navigate to device selection page
- [ ] Select test device
- [ ] Click "Collect Facts" button
- [ ] Verify:
  - [ ] Progress UI appears
  - [ ] Job completes successfully
  - [ ] Facts displayed in comparison view
  - [ ] No errors in logs

## Security Hardening

### 16. Credential Security
- [ ] Credentials stored in environment variables (not configuration files)
- [ ] Environment files have restricted permissions (600)
- [ ] Credentials rotated on schedule
- [ ] No credentials committed to version control

### 17. Network Security
- [ ] Management network segmentation verified
- [ ] Firewall rules restrict SSH access
- [ ] Legacy SSH algorithms reviewed with security team
- [ ] Connection logs monitored for anomalies

### 18. Access Control
- [ ] NetBox permissions configured for plugin access
- [ ] Only authorized users can trigger collections
- [ ] Audit logging enabled for plugin actions

## Monitoring Setup

### 19. Application Monitoring
- [ ] Monitor job failure rates:
  ```sql
  SELECT COUNT(*) FROM extras_job
  WHERE object_type='netbox_network_ops.factscollectionjob'
  AND status='failed';
  ```
- [ ] Monitor collection times (should be < 30s)
- [ ] Alert on persistent authentication failures

### 20. Infrastructure Monitoring
- [ ] RQ worker process monitored (systemd or Docker healthcheck)
- [ ] Redis queue depth monitored
- [ ] NetBox application logs monitored

## Documentation Review

### 21. Team Documentation
- [ ] Operations team has access to DOCUMENTATION.md
- [ ] Troubleshooting guide reviewed: DOCUMENTATION.md → Troubleshooting
- [ ] Support contacts documented
- [ ] Runbook created for common issues

### 22. Backup and Recovery
- [ ] Database backup includes `netbox_network_ops_devicefacts` table
- [ ] Configuration backup includes plugin settings
- [ ] Rollback procedure documented

## Production Cutover

### 23. Final Checks
- [ ] All checklist items complete
- [ ] Test collections successful on 3+ devices
- [ ] No errors in logs
- [ ] RQ worker healthy
- [ ] Team trained on plugin usage

### 24. Go Live
- [ ] Announce plugin availability to team
- [ ] Monitor for first hour after go-live
- [ ] Document any issues encountered
- [ ] Schedule follow-up review in 1 week

## Post-Deployment

### 25. Operational Excellence
- [ ] Establish credential rotation schedule
- [ ] Set up regular audits of failed collections
- [ ] Monitor for platform support expansion needs
- [ ] Collect user feedback for v1.1 planning

---

## Quick Reference

**Package:** `netbox-network-ops-v1.0.tar.gz`
**Checksum:** `34e6d2b4a723651b659698adf7df84abc4b34983e64e57520207eceb01b866c8`
**Version:** 1.0.0
**Installation:** `pip install /path/to/netbox-network-ops-v1.0`
**Documentation:** See `netbox-network-ops-v1.0/DOCUMENTATION.md`

**Support Files:**
- QUICKSTART.md - 5-minute quick start
- INSTALL.txt - Detailed installation
- DEPLOYMENT.md - Production deployment guide
- DOCUMENTATION.md - Comprehensive documentation

---

Deployment checklist v1.0 - 2026-01-29
